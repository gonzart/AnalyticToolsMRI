function S_hrt_protocol = createSignalHRTensor_bs(HRT_coeff,nCoef,CoeffDeff,mu,protocol)
bs = GetB_Values(protocol)';
tam_protocolo = length(bs);
idxDW = (bs~=0);
bs = bs(idxDW);
orientations = protocol.grad_dirs(idxDW,:);
NLEC = length(bs);
%reconstruct generalized DT signal
S_hrt_norm = zeros(NLEC,1);
for i=1:NLEC
    gDg=0;
    
    for k=1:nCoef
        prod_g =1;
        for j=1:size(CoeffDeff,2);
            prod_g = prod_g * orientations(i,CoeffDeff(k,j));
        end
        gDg = gDg + prod_g * HRT_coeff(k) * mu(k);
    end
    S_hrt_norm(i) = exp(-bs(i)*gDg);
end

S_hrt_protocol = ones(tam_protocolo,1); % poner las S0
S_hrt_protocol(idxDW) = S_hrt_norm;

end
function  [l1, l23, fa ]= lambdas_from_multicompIntraExtra(x_intra, x_extra, alpha_intra, alpha_extra, fibredirDada, roots, protocol, S0_per_TE_all,X_dt) 
%Crea un modelo multicompartimiento al que le ajusta un tensor y calcula la
%diferencia entre los valores propios de ese tensor y los que recibe como
%par??metros 
%MAOP - 20150715
        

        signal_intra_extra_iso = create_signal_intra_extra_iso(x_intra, x_extra, alpha_intra, alpha_extra, fibredirDada, roots, protocol, S0_per_TE_all,X_dt);

        % DT model    
        D = FitLinearDT(signal_intra_extra_iso, protocol);
        fa = getFA(D);
        ls = getEigenVals(D);
%         fibredir = getPDD(D);
        
        l1 = ls(1);
        l23 = (ls(2)+ls(3))*0.5;
        
end


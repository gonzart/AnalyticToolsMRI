function [DBFs vecsDisp] = rotationalBasis(dir,nRotations,angle,protocol,di,dr1,dr2,bs,idxDW)
 

    lecDir = protocol.grad_dirs(idxDW,:);
    
    NLEC = size(lecDir,1);
    
    DBFs = zeros(NLEC,nRotations);
    vecsDisp = zeros(nRotations,3);
    
    
    T = [di 0 0 ; 0 dr1 0 ; 0 0 dr2];

    theta = 0;
    mtx = fromToRotation([1 ;0 ;0], dir); %compute rotation matrix
    for j=1:nRotations

        
        vecDisp = [0 ;1 ;0];
        
        rot_x = [1 0 0 ; 0 cos(theta) -sin(theta); 0 sin(theta) cos(theta)];
        
        Ti = rot_x * T * rot_x';
        VecDispi = rot_x * vecDisp;
        Ti = mtx * Ti * mtx';
        vecsDisp(j,:) = (mtx * VecDispi)';
        
        
        %compute the DW-signals for each tensor
        for i=1:NLEC
             DBFs(i,j) = exp(-bs(i) * lecDir(i,:) * Ti * lecDir(i,:)');
        end
        
        theta = theta + angle;
        
    end
    

end

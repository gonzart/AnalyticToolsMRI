function CreateROI_multipleNIIs(dwi_prefix_file,idxs_files, maskfile, outputfile)
%
% function CreateROI_multipleNIIs(dwi_prefix_file,idxs_files, maskfile, outputfile)
%
% This function converts a set of 3-D DWI volumes into the data format suitable
% for subsequent NODDI fitting.
%
% Inputs:
%
% dwi_prefix_file: generic string format of  NIfTI or Analyze filename 
%
% idxs_files: indexes of files
%
% maskfile: the brain mask volume in NIfTI or Analyze format which
% specifies the voxels to include for fitting
%
% outputfile: the mat file to store the resulting data for subsequent
% fitting
%
% author: Alonso Ramirez
%

% first check if niftimatlib is available
if (exist('nifti') ~= 2)
    error('niftimatlib does not appear to be installed or included in the search path');
    return;
end

% load the DWI volume
fprintf('loading the DWI volume : %s\n', dwi_prefix_file);

idx_f = idxs_files(1);
dwi_i = nifti( sprintf(dwi_prefix_file,idx_f ));
xsize = dwi_i.dat.dim(1);
ysize = dwi_i.dat.dim(2);
zsize = dwi_i.dat.dim(3);
ndirs = length(idxs_files);

dwi = zeros(xsize,ysize,zsize,ndirs) ;

dwi(:,:,:,idx_f) = dwi_i.dat(:,:,:);

count = 2;
for idx_f=idxs_files(2:end)
    dwi_i = nifti( sprintf(dwi_prefix_file,idx_f ));
    dwi(:,:,:,count) = dwi_i.dat(:,:,:);
    count = count+1;
end



% convert the data from scanner order to voxel order
dwi = permute(dwi,[4 1 2 3]);

% load the brain mask volume
fprintf('loading the brain mask : %s\n', maskfile);
mask = nifti(maskfile);
mask = mask.dat(:,:,:);

% create an ROI that is in voxel order and contains just the voxels in the
% brain mask
fprintf('creating the output ROI ...\n');

% first get the number of voxels first
% to more efficiently allocate the memory
count=0;
for i=1:xsize
    for j=1:ysize
        for k=1:zsize
            if mask(i,j,k) > 0
                count = count + 1;
                mask(i,j,k) = count;
            end
        end
    end
end
roi = zeros(count,ndirs);
idx = zeros(count,3);

% next construct the ROI
count=0;
for i=1:xsize
    for j=1:ysize
        for k=1:zsize
            if mask(i,j,k) > 0
                count = count + 1;
                roi(count,:) = dwi(:,i,j,k);
                idx(count,:) = [i j k];
            end
        end
    end
end

% save the ROI
fprintf('saving the output ROI as %s\n', outputfile);
save(outputfile, 'roi', 'mask', 'idx','-v7.3');

disp('done');


function [nB, dirB, scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT_max] ...
    =  getBundlesFromDBF(meas,protocol,BasisDirOrig,sig,SNR,x1,x3,x5)

%global Sh1 Sr1 Siso1 Sh2 Sr2
global actualFibreDir1 actualFibreDir2 NGT

 % generates separated signals for hindered an restricted from vector x as
% x(1) = 0.5; %is the volume fraction of the intracellular space.
% x(2) = 1.7e-9; %is the free diffusivity of the material inside and outside the cylinders.
% x(3) = 4; %is the concentration parameter of the Watson's distribution.
% x(4) = 0.2; %is the volume fraction of the isotropic compartment.
% x(5) = 3e-9; %is the diffusivity of the isotropic compartment.
% x(6) = S0; %is the measurement at b=0.

% parameters to explore

    lambda = 8.25/SNR;  %8.25   2750/SNR; %1000000*sig;
    
    options = optimset('lsqnonneg');
    optnew = optimset(options,'Display','off');

    %if nargin < 6 
        %x1 = 0.05:0.1:0.95; % important to propose  dpar
        x2 = 1.7e-9; %(1.5:0.25:2.0)*1e-9; % di
        %x3 = 2:4:14; % dispersion
        %x5 = 3.0e-9;

        xs = combvec(x1,x2,x3,x5);
        nCom = size(xs,2);
        dumy = ones(1,nCom);
        %      icvf        di        kappa     fiso   diso   b0   
        xs = [xs(1,:) ; xs(2,:) ; xs(3,:) ; dumy ; xs(4,:); dumy];
        testAngles = 1;

    %else
    %    %xs = [0.5; 1.7e-9; 16; 1; 3e-9;1];
    %    nCom = 1;
    %    xs = x_max;
    %    testAngles = 1;
    %end
    



    bs = GetB_Values(protocol)';
    idxB0 = (bs==0);
    idxDW = (bs~=0);
    
    orientations = protocol.grad_dirs(idxDW,:);


    S0r = mean(meas(idxB0));
    Si = meas(idxDW);

    quality_max = -1e30;   x_max = []; alphas_max = []; DBFsFoc_max=[]; % initialization

    found = 0;
 
for n_angle = 1:testAngles
    if n_angle > 1
        BasisDir = perturbBasisDir(BasisDirOrig,5);
    else
        BasisDir = BasisDirOrig;
    end
        
    for k=1:nCom
        
        %BasisDir =[1 0 0 ; 0 1 0; cos(pi/4) sin(pi/4) 0;cos(pi/8) sin(pi/8) 0];
        [DBFsFoc , idxAnisotropic, idxIsotropic,dIsoCoeff] = createDBF_NODDI_WatsonSHStickTortIsoV_B0( BasisDir, orientations, protocol,xs(:,k));
        
        %Solving DBF
        A = S0r*DBFsFoc;
        if x5 == 0 % do not use ball
            [alphas_i, RESNORM,~,EXITFLAG_OPT] = lsqnonneg(A(:,1:end-1),Si,optnew);
            %[alphas_i,RESNORM,EXITFLAG_OPT] = myNNLS(A(:,1:end-1),Si);
            alphas_i= [alphas_i; 0];
        else
            [alphas_i, RESNORM,~,EXITFLAG_OPT] = lsqnonneg(A,Si,optnew);
            %[alphas_i,RESNORM,EXITFLAG_OPT] = myNNLS(A,Si);
        end

        

        n_alphas_i = sum(alphas_i(idxAnisotropic) > 0.05);        
        pred_DBF_S_i        = meas; pred_DBF_S_i(idxDW) = A*alphas_i;
        loglikDBF_i = -RESNORM; %RicianLogLik(meas, pred_DBF_S_i, sig);
        quality_i = loglikDBF_i - lambda*n_alphas_i; % 1000 before
        
        if quality_i > quality_max && n_alphas_i >0
                found = 1;
                %fprintf('\n   improving to (%d %.1f)',n_alphas_i,loglikDBF_i);
                n_alphas_max = n_alphas_i;
                quality_max = quality_i;
                x_max = xs(:,k);
                alphas_max = alphas_i;
                pred_DBF_S_max = pred_DBF_S_i;
                loglikDBF_peak_max = loglikDBF_i;
                DBFsFoc_max = DBFsFoc;
                dIsoCoeff_max = dIsoCoeff;
                EXITFLAG_OPT_max = EXITFLAG_OPT;
        end
        
    
    end
    
    if found
        
        
        nAniso = size(idxAnisotropic,2);
        
        %alphas_h_r = alphas_max(1:nAniso/2) + alphas_max(nAniso/2+1:nAniso);
        alphas_h_r = alphas_max(1:nAniso);
    
        [nB, dirB, scB, ~, idx_Peaks] = ...
            getDBF_NODDI_peaks_restricted(BasisDir,alphas_h_r,nAniso);
            %getDBF_NODDI_peaks_restricted(BasisDir,alphas_h_r,nAniso/2);
        
        szCr = x_max(1);
        szCh = 1-x_max(1);
        
        szCIso = alphas_max(idxIsotropic(1:end)); %alphas_max(idxIsotropic(1:end-1));, before we used dot
        if isempty(szCIso>0.01) 
            cIso = 0;
        else
            cIso = dIsoCoeff_max(szCIso>0.01);
            szCIso = szCIso(szCIso>0.01);
            if isempty(szCIso)
                szCIso = 0;
            end
        end
        
        szCDot = 0; %alphas_max(end);
        
        %idxSelected = [idx_Peaks nAniso/2+idx_Peaks idxIsotropic(alphas_max(idxIsotropic)>0.05) ];
        idxSelected = [idx_Peaks  idxIsotropic(alphas_max(idxIsotropic)>0.05) ];
        
        predB_S        = meas;
        predB_S(idxDW) = S0r*DBFsFoc_max(:,idxSelected)*alphas_max(idxSelected);
        loglikB = RicianLogLik(meas, predB_S, sig);
        
    else
        nB = 0;
        dirB=[0,0,0]; scB=0; szCh=0; szCr=0; 
        
        predB_S=pred_DBF_S_i; 
        loglikB=loglikDBF_i;
        x_max=xs(:,nCom);
        
        
        szCIso = alphas_i(idxIsotropic(1:end));
        if isempty(szCIso>0.05) 
            cIso = 0;
        else
            cIso = dIsoCoeff(szCIso>0.05);
            szCIso = szCIso(szCIso>0.05);
            if isempty(szCIso)
                szCIso = 0;
            end
        end
        szCDot = 0; %alphas_i(end);
        EXITFLAG_OPT_max = EXITFLAG_OPT;

    end

end


end
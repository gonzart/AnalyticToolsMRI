function S0_per_TE_out = computeS0_per_TE_fromMeas(S0_per_TE,protocol,protocol_out)


S0_per_TE_out = zeros(protocol_out.totalmeas,1);
for i=1:length(protocol_out.uTE)
    
    %idxB0 = intersect ( find(protocol.TE == protocol.uTE(i)),protocol.b0_Indices);
    %S0_TE = mean(meas(idxB0));
    idxDW = find(protocol.TE == protocol_out.uTE(i));

    
    idxDW_out = find(protocol_out.TE == protocol_out.uTE(i));
    
    S0_per_TE_out(idxDW_out) = S0_per_TE(idxDW(1));
end

%challenge 2015
clc; clear; close all


cruceVoxelType = true;

format long g

my_path = '/Users/alram/Dropbox/matlabs/data/challengeISBI2015/';


%prepare for output
my_file_out = 'unseenScheme.txt';
[bval_out, bvec_out,G_out,delta_out,DELTA_out, TE_out ]=readChallenge2015ProtocolData(my_path,my_file_out);
protocol_out = Challenge2015_2_Protocol(bval_out, bvec_out,G_out,delta_out,DELTA_out,TE_out);
roots = BesselJ_RootsCyl();

my_path = '/Users/alram/Dropbox/matlabs/data/challengeISBI2015/send/';

if cruceVoxelType
    filenameSignal_out = 'unseenSignalX.txt';
else
    filenameSignal_out = 'unseenSignals.txt';
end

[ss(:,1), ss(:,2), ss(:,3), ss(:,4), ss(:,5), ss(:,6)] = textread([my_path filenameSignal_out ],'%f %f %f %f %f %f','headerlines', 1);
meas_all = ss(:,6);

    protocol_all = Challenge2015_2_Protocol(bval_out, bvec_out,G_out,delta_out,DELTA_out,TE_out); % complete  protocol without  B0 ni DW outiers
    S0_per_TE_all = compute_S0_per_TE(protocol_all,meas_all);
    sig_per_TE_all = sigmaFromB0_difTE(S0_per_TE_all,protocol_all);

h = figure; VoxelDataViewer_DifTE(protocol_all, meas_all, [0; 0; 1.0], h)
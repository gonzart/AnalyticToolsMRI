function boostrapingDBF(meas,protocol,sig,SNR,nboostrap) %BasisDir, ,x1,x3,x5

    global actualFibreDir1 actualFibreDir2 %NGT

    
    %path_data = '/Users/alram/Dropbox/matlabs/data/NODDI_example_dataset/';
    %DBFDirectionsFileName = [path_data 'DBF_129orientations.dat'];
    %BasisDir = load(DBFDirectionsFileName);
    [nB_t, dirB_t, scB_t, szCr_t, ~ ,~, szCIso_t ,~, ~,maxloglikB_t ,~,~] =...
        DBF_NODDI_fit(meas,protocol,sig,SNR);
    
   
    
    bs = GetB_Values(protocol)';
       
    outs = find(bs ~= 0);
    outs = outs(randperm(length(outs)));

    
    tic
    cell_proto = cell(nboostrap,1);
    new_meas = zeros(nboostrap,length(bs)-1);
    for n=1:nboostrap
        protocol_l = protocol;
        out = outs(mod(n-1,72)+1);
        protocol_l.totalmeas = protocol_l.totalmeas - 1;
        if bs(out) == bs(2)
            protocol_l.N(1) = protocol_l.N(1) -1;
        else
            protocol_l.N(2) = protocol_l.N(2) -1;            
        end
        new_idx = setdiff(1:protocol.totalmeas,out);
        protocol_l.delta = protocol_l.delta(new_idx);
        protocol_l.smalldel = protocol_l.smalldel(new_idx);
        protocol_l.G = protocol_l.G(new_idx);
        protocol_l.grad_dirs = protocol_l.grad_dirs(new_idx,:);
        cell_proto{n} = protocol_l;
        new_meas(n,:) = meas(new_idx);
    end

    
    r= cell(nboostrap,1);
    %x1 = 0.5;   x3=22;  x5 = 3e-9;
    %myPool = parpool(min(12,nboostrap));
    
    %par
    for n=1:nboostrap
        
        protocol_l = cell_proto{n};
        [nB, dirB, scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] =...
            DBF_NODDI_fit(new_meas(n,:)',protocol_l,sig,SNR);
            %getBundlesFromDBF(meas,protocol_l,BasisDir,sig,SNR,x1,x3,x5)
        
        r{n} = {nB, dirB, scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT};
    end
    %delete(gcp('nocreate'))

    toc
    
    
    figure; 
    hold on;
    plot3(actualFibreDir1(1),actualFibreDir1(2),actualFibreDir1(3),'bd');
    plot3(actualFibreDir2(1),actualFibreDir2(2),actualFibreDir2(3),'bd');
    
    for i=1:nB_t
        plot3(dirB_t(i,1),dirB_t(i,2),dirB_t(i,3),'gx');
    end
    
    
    plot3(1,0,0,'ko');    plot3(-1,0,0,'ko');    plot3(0,1,0,'ko');    
    plot3(0,-1,0,'ko');   plot3(0,0,1,'ko');    plot3(0,0,-1,'ko');
    
    maxIdx = -1;
    maxloglikB = -1e30;
    
    for n=1:nboostrap

        nB = r{n}{1};
        dirB = r{n}{2};
        scB = r{n}{3};
        szCr = r{n}{4};
        szCIso = r{n}{7};
        loglikB = r{n}{10};
        out = outs(mod(n-1,72)+1);
        
        if loglikB >= maxloglikB && nB == 2 
            maxloglikB = loglikB;
            maxIdx = n;
            max_nB = nB;
            max_dirB = dirB;
        end
        
        %[nB, dirB, scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] =...
        %    DBF_NODDI_fit(meas(new_idx),protocol_l,sig,SNR);
        %    %getBundlesFromDBF(meas,protocol_l,BasisDir,sig,SNR,x1,x3,x5);
        
        fprintf('\n b(out) = %d - nB = %d scB1= %f scB2 = %f  szCr = %f szCIso = %f ',bs(out), nB,scB(1),scB(2),szCr,szCIso);
        
        for i=1:nB
            plot3(dirB(i,1),dirB(i,2),dirB(i,3),'r+');
        end
        
    end

    
    fprintf('\n\n All ***   nB_t %f,  szCr_t %f szCIso_t %f maxloglikB_t %f \n',nB_t, szCr_t,szCIso_t, maxloglikB_t);
    display(scB_t)
    
    fprintf('\n\n BEST ***   max_nB %f, maxloglikB %f \n',max_nB,maxloglikB );

    for i=1:max_nB
        plot3(max_dirB(i,1),max_dirB(i,2),max_dirB(i,3),'k+');
    end
    
    %nB = r{maxIdx}{1};
    %dirB = r{maxIdx}{2};
    scB = r{maxIdx}{3};
    szCr = r{maxIdx}{4};
    szCIso = r{maxIdx}{7};
    %loglikB = r{maxIdx}{10};
    out = outs(mod(maxIdx-1,72)+1);
    
    fprintf('\n  b(out) = %d -  szCr = %f szCIso = %f ',bs(out),szCr,szCIso);
    display(scB)
    hold off;
end
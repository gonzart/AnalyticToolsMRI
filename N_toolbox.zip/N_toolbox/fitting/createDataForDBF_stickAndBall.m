function [cosT_2_b,sinT_2_b]  = createDataForDBF_stickAndBall(protocol,BasisDir)


    bs = GetB_Values(protocol)';
    idxDW = (bs~=0);
    bs = bs(idxDW);
    
    lecDir = protocol.grad_dirs(idxDW,:);
    
    cosT = abs(lecDir*BasisDir');
    cosT(cosT>1) = 1;
    
    cosT_2 = cosT.^2;
    sinT_2 = 1 - cosT_2;
    
    BS = repmat(bs,1,size(BasisDir,1));
    
    cosT_2_b = - BS .* cosT_2;
    sinT_2_b = - BS .* sinT_2;


    
end

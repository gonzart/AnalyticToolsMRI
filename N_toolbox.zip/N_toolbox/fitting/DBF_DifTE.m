function [peaks,S_dbf,RESNORM,weightDir] = DBF_DifTE(protocol,meas,S0_per_TE) %,di,dp)

bs = GetB_Values(protocol)';
idxDW = (bs~=0);

path_data = '/Users/alram/Dropbox/matlabs/data/NODDI_example_dataset/';
DBFDirectionsFileName = [path_data 'DBF_129orientations.dat'];
%DBFDirectionsFileName = [path_data 'PuntosElectroN2000.txt'];

BasisDir = load(DBFDirectionsFileName);
nDir = size(BasisDir,1);

% extra celular space
di = 1.7*1e-9; % di
dp = (1.7/4.5)*1e-9; % radial diff

X = DT_DesignMatrix(protocol);
X = X(idxDW,2:end);

DBF = createDBF_bs( di, dp, BasisDir, size(X,1)  ,X);
Eiso = SynthMeasIsoGPD(3e-9, protocol);
DBF = [DBF Eiso(idxDW)];


S0_per_TE_matrix = repmat(S0_per_TE(idxDW),1,nDir+1);
DBF = DBF .* S0_per_TE_matrix;

DBF(:,nDir+2) = 1; % dot


options = optimset('lsqnonneg');
optnew = optimset(options,'Display','off');

[alphas, RESNORM,~,EXITFLAG_OPT] = lsqnonneg(DBF,meas(idxDW),optnew);

idxOn = alphas > 0.05;

peaks = BasisDir(idxOn(1:nDir),:); % all dirs

[weightDir,idxSort] = sort(alphas(idxOn(1:nDir)), 'descend');

peaks = peaks(idxSort,:);

S_dbf = DBF * alphas; % signal reconstruction
%t = meas; % temp for signal generation
t = S0_per_TE;
t(idxDW) = S_dbf; 
S_dbf = t;


end


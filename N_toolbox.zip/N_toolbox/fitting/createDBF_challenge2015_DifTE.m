function DBFs = createDBF_challenge2015_DifTE( BasisDir, protocol,intra_x,roots)
%createDBF      Compute the DBFs matrix for the DBF model.
%
%   DBFs = createDBF_NODDI( x, BasisDir, lecDir , nTensoresBase, NLEC, bs)
%   Compute the the DBFS (for different b values) matrix given the basis-tensor's longitudinal and transversal 
%   diffusion DPDD and DTRA for the set of orientations BASISDIR and for the set of
%   diffusion encoding orientation (MRI machine gradient directions) LECDIR and b-value
%   B, as is explained in:
%   A. Ramirez-Manzanares etal, Diffusion Basis Functions Decomposition for Estimating 
%   White Matter Intravoxel Fiber Geometry. IEEE Trans. Med. Imaging 26(8): 2007.
%
%   Alonso Ramirez.  
%   $Date: 2008/10/21$

bs = GetB_Values(protocol)';
idxDW = (bs~=0);

nTensoresBase = size(BasisDir,1);
NLEC = sum(idxDW);

DBFs = zeros(NLEC,nTensoresBase); % N restricted

for j=1:nTensoresBase
    
    %signal = SynthMeasWatsonSHCylSingleRadTortIsoV_GPD_B0_DifTE(meas,intra_x, protocol, BasisDir(j,:)', roots);
    signal = SynthMeasCylNeuman_PGSE(intra_x, protocol.grad_dirs, protocol.G', protocol.delta', protocol.smalldel', BasisDir(j,:)', roots);
    DBFs(:,j) = signal(idxDW);
    
end


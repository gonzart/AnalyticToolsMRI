function [Ss_individual]=spheres_S(spheres,protocol,coeff_diff)
%Example to create sphere signal. 
% [Ss_individual]=spheres_S(spheres,protocol,coeff_diff)
% Ss_individual return an array, the one wich content the singal for each
% sphere.
% spheres: Array n(spehres)x 4(X Y Z rad). The array sphere content the
% position of the sphere and the radium of itself, for each sphere.
%
% protocol: Is the usual protocol create by th function 
% protocol: Challenge2015_2_Protocol 
% coeff_diff: Is the diffusivity of the material inside the sphere.
% Set substrate
% coeff_diff = 2.0e-9; %m^2/s
format long;
global VecLePars;
global VecLePerps;
N_sphere =length(spheres(:,1));

[Spheres_S,Ss_individual,compartmentSizes]= createSignalsSubstrateSpheres(spheres(:,4),coeff_diff,N_sphere,protocol);


end


function [S_tot,Ss_individual,compartmentSizes] = createSignalsSubstrateSpheres(rads,coeff_diff,N_sphere,protocol)
    roots = BesselJ_RootsSphere();
    for i=1:N_sphere
        intra_x = [coeff_diff;rads(i)];
        Ss_individual(:,i) = SynthMeasSphereNeuman_PGSE(intra_x, protocol.grad_dirs, protocol.G', protocol.delta', protocol.smalldel', roots);
    end
    compartmentSizes = pi*rads.^2;
    compartmentSizes = compartmentSizes ./ sum(compartmentSizes);
    
    %figure; plot(rads,compartmentSizes);
    
    S_tot = Ss_individual * diag(compartmentSizes);
    S_tot = sum( S_tot, 2);
end
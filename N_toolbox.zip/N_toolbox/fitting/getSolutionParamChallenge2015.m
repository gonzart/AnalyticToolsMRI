function getSolutionParamChallenge2015(protocol,idxDW,fibreDir,alphas,S0_per_TE,roots)

[BasisDirFocused,nDir,xs_intra,nCom_intra,ds_extra,nComExtra,dIso,nIsoComp,X_dt] = setParamsDBFChallenge2015(protocol,idxDW,fibreDir);
DBFs_tot = createDBF_intra_extra_iso_Chall2015(BasisDirFocused,xs_intra,nCom_intra,ds_extra,nComExtra,dIso,nIsoComp,X_dt,S0_per_TE,roots,idxDW,nDir,protocol);
    
    
idxOn = find(alphas > 0.005);

alphas_i_On = alphas;
alphas_i_On( setdiff(1:length(alphas),idxOn )) = 0;

idxOnAniso = idxOn( idxOn <= (nCom_intra+nComExtra)*nDir );
idxOnAniso_intra = idxOnAniso( idxOn <= nCom_intra*nDir );
idxOnAniso_extra = setdiff( idxOnAniso, idxOnAniso_intra ) ;

idxOnIso   = idxOn( idxOn  > (nCom_intra+nComExtra)*nDir & idxOn ~= size(DBFs_tot,2) ); % remove dot

idxOrient = mod(idxOnAniso-1,nDir)+1;

dirsOn = BasisDirFocused(idxOrient,:); % all dirs, separate latter intra and extra

%figure(500); 
%hold on; plot3(dirsOn(:,1),dirsOn(:,2),dirsOn(:,3),'k^'); 
%axis equal;


idx_confs_intra = ceil(idxOnAniso_intra /  nDir); % idx of confs , without the basis direc idx
idx_confs_extra = ceil(idxOnAniso_extra /  nDir) - nCom_intra; % idx of confs , without the basis direc idx
idx_confs_iso = idxOnIso - (nCom_intra+nComExtra)*nDir;

format long g

fprintf('%%%%%%%%%%%%%%%%%% PARAMS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');
% OLD
% xs_intra(:,idx_confs_intra) % intra used confs
% ds_extra(:,idx_confs_extra) % extra used confs
% 
% dIso(idx_confs_iso) % used dIsos

 fprintf('\n Intra \n');   [xs_intra(:,idx_confs_intra);alphas(idxOnAniso_intra)'] % intra used confs
 fprintf('\n Extra \n');   [ds_extra(:,idx_confs_extra);alphas(idxOnAniso_extra)'] % extra used confs
    
 fprintf('\n Iso \n');  [dIso(idx_confs_iso);alphas(idxOnIso)'] % used dIsos
 fprintf('\n Dot \n');  []; % alphas(end)%dot 

fprintf('%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%');

    
    
end
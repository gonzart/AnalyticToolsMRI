function S_dt = evalDT_DifTE(D,meas,protocol)

S0_per_TE = compute_S0_per_TE(protocol,meas);

X = DT_DesignMatrix(protocol);
X = X(:,2:end);
S_dt = S0_per_TE .* exp(X*D(2:end));

end
function  error = error_lambdas_multicomp(lambda1, lambda23, x_intra, x_extra, alpha_intra, alpha_extra, fibredirDada, roots, protocol, S0_per_TE_all) 
%Crea un modelo multicompartimiento al que le ajusta un tensor y calcula la
%diferencia entre los valores propios de ese tensor y los que recibe como
%parámetros 
%MAOP - 20150715
        % Crea la señal intra
        signal_intra = SynthMeasCylNeuman_PGSE(x_intra, protocol.grad_dirs, protocol.G', protocol.delta', protocol.smalldel', fibredirDada, roots);    

        % Crea la señal extra
        X_dt = DT_DesignMatrix(protocol);
        X_dt = X_dt(:,2:end);
        signal_extra = createDBF_bs( x_extra(1), x_extra(2), fibredirDada', size(X_dt,1)  ,X_dt);

        %Crea la señal iso
        signal_iso = SynthMeasIsoGPD(3*10^(-9), protocol);
   
        %Se suman las señales
        signal_intra_extra_iso = alpha_intra*signal_intra + alpha_extra*signal_extra + (1 - alpha_intra - alpha_extra)*signal_iso;
        signal_intra_extra_iso = signal_intra_extra_iso .* S0_per_TE_all;

        % DT model    
        D = FitLinearDT(signal_intra_extra_iso, protocol);
        fa = getFA(D);
        ls = getEigenVals(D);
%         fibredir = getPDD(D);
        
        l1 = ls(1);
        l23 = (ls(2)+ls(3))*0.5;
        
        error = (lambda1 - l1)^2 + (lambda23 - l23)^2;         
end
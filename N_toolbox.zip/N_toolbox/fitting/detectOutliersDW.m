function outliersDW = detectOutliersDW(E, protocol)

outliersDW = [];
for i=1:length(protocol.uTE)
    idxB0 = intersect ( find(protocol.TE == protocol.uTE(i)),protocol.b0_Indices);
    S0_TE = mean(E(idxB0));
    idxDW = find(protocol.TE == protocol.uTE(i));
    
    
    %outlier detection %%%%%%%%%%%%%%%%
    idxDWHigh = setdiff(idxDW,protocol.b0_Indices);
    idxDWHigh = intersect(find(E > S0_TE),idxDWHigh);
    
    if ~isempty(idxDWHigh) > 0
%         disp(['S0= ' num2str(S0_TE) ' TE= ' num2str(protocol.uTE(i))])
%         disp('idxData val G DELTA delta b');
%         disp([idxDWHigh E(idxDWHigh) 1000*protocol.G(idxDWHigh)' 1000*protocol.delta(idxDWHigh)' 1000*protocol.smalldel(idxDWHigh)' floor(1e-6*protocol.B(idxDWHigh)')]);
        outliersDW = [outliersDW ; idxDWHigh];
    end
    
    
end
% display('list of outliers');
% 
% fprintf('[');
% fprintf('%d, ',outliersDW(1:end-1));
% fprintf('%d]',outliersDW(end));

end
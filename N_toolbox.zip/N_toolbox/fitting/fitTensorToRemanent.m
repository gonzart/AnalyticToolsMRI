function [T STensorProt]= fitTensorToRemanent(SPeaksPar,PeakCoef,SBall,BallSC,meas,protocol,recoveredFibreDir,b0)

    bs = GetB_Values(protocol)';
    %idxB0 = (bs==0);
    idxDW = (bs~=0);

    SPeaks = SPeaksPar(:,1);
    SPeaks(idxDW) = sum(SPeaksPar(idxDW),2);

    rep = meas;
    rep(idxDW) = PeakCoef*SPeaks(idxDW)+BallSC*SBall(idxDW);
    %seeSignalQlty(meas,rep,protocol,recoveredFibreDir,b0); title 'meas rep'
    
    
    dif = meas;
    dif(idxDW) = meas(idxDW)-PeakCoef*SPeaks(idxDW)-BallSC*SBall(idxDW);
    
    dif(dif<=0) = 0.1;
    %seeSignalQlty(meas,dif,protocol,recoveredFibreDir,b0); title 'meas dif'
    
    D = FitLinearDT(dif, protocol);

    T = MakeDT_Matrix(D(2), D(3), D(4), D(5), D(6), D(7));
    
    [a b] = eig(T);
    
    
        
    
    bs = bs(idxDW);
    lecDir = protocol.grad_dirs(idxDW,:);
    
    NLEC = size(bs,1);
    STensor = zeros(NLEC,1);
    for i=1:NLEC
        STensor(i) = exp(-bs(i) * lecDir(i,:) * T * lecDir(i,:)');
    end
    STensor = b0*STensor;

    
    
    STensorProt = meas;
    STensorProt(idxDW) = STensor;

    %seeSignalQlty(dif,STensorProt,protocol,a(:,3),b0); title 'dif,STensorProt'
    
    %seeSignalQlty(meas,PeakCoef*SPeaks+STensorProt,protocol,recoveredFibreDir,b0); title 'meas,PeakCoef*SPeaks+STensorProt'
    

end


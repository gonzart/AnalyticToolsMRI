function signal_intra_extra_iso = create_signal_intra_extra_iso(x_intra, x_extra, alpha_intra, alpha_extra, fibredirDada, roots, protocol, S0_per_TE_all,X_dt)
        % Crea la se??al intra
        signal_intra = SynthMeasCylNeuman_PGSE(x_intra, protocol.grad_dirs, protocol.G', protocol.delta', protocol.smalldel', fibredirDada, roots);    

        % Crea la se??al extra
        signal_extra = createDBF_bs( x_extra(1), x_extra(2), fibredirDada', size(X_dt,1)  ,X_dt);

        %Crea la se??al iso
        signal_iso = SynthMeasIsoGPD(3*10^(-9), protocol);
   
        %Se suman las se??ales
        signal_intra_extra_iso = alpha_intra*signal_intra + alpha_extra*signal_extra + (1 - alpha_intra - alpha_extra)*signal_iso;
        signal_intra_extra_iso = signal_intra_extra_iso .* S0_per_TE_all;
end
function analizeNODDIData(var,var2,noddi,protocol,model_str)

nVoxels = size(var.roi,1);
idxsvar = var.idx;

fa = zeros(nVoxels,1);
di = [];
diso = [];
kappa =  [];
%irfrac = [];
ficvf = [];
fiso = [];
noddiRicLik =  [];


count = 0;

for v = 1:nVoxels 
     
    meas = var.roi(v,:)';
        
        
    % get NODDI results
    [b0, S_NODDI, recoveredFibreDir, loglikNODDI, sigNODDI,] = getFitedDataNoddi(meas,noddi,protocol,var2.mlps(v,:));
    seeSignalQlty(meas,S_NODDI,protocol,recoveredFibreDir,b0); title 'S NODDI'
    %fprintf(' NODDI %09.1f\t',loglikNODDI);


    % Fit Diff. Tensor
    [D, STensor] = FitLinearDT(meas, protocol);
    if sum(isinf(D))>0
        continue;
    end
    pdd = getPDD(D);
    fa(v) = getFA(D);
    if fa(v)<0.7 || fa(v) > 0.95
        continue
    end
    
    count = count +1;
    
    fprintf('\n%03d (%02d %02d %02d)',v,idxsvar(v,:));
    seeSignalQlty(meas,STensor,protocol,pdd,b0); title 'S DT'
     
    di(count)   = var2.mlps(v,GetParameterIndex(model_str,'di') ); 
    diso(count) = var2.mlps(v,GetParameterIndex(model_str,'diso') ); 
    kappa(count) = var2.mlps(v,GetParameterIndex(model_str,'kappa') ) * 10; 
    %irfrac(count) = var2.mlps(v,GetParameterIndex(model_str,'irfrac') );
    ficvf(count) = var2.mlps(v,GetParameterIndex(model_str,'ficvf') );
    fiso(count) =  var2.mlps(v,GetParameterIndex(model_str,'fiso') );
    noddiRicLik(count) = loglikNODDI;
    

     
end

figure; hist(fa,25); title 'FA'
figure; hist(di,25); title 'di'
figure; hist(diso,25); title 'diso'
figure; hist(kappa,25); title 'kappa'
figure; hist(ficvf,25); title 'ficvf'
%figure; hist(irfrac,25); title 'irfrac'
figure; hist(fiso,25); title 'fiso'

figure; hist(noddiRicLik,25); title 'noddiRicLik'



end
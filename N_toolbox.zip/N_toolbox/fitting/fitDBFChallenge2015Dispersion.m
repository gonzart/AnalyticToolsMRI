function [ alphas, S_dbf,RESNORM]= fitDBFChallenge2015Dispersion(fibreDir,protocol,meas,S0_per_TE,empir_sig_per_TE)

wFact = 0.0; % 1 is regular LS
Ws = sqrt(   (min(empir_sig_per_TE) ./ empir_sig_per_TE)*(1-wFact) + wFact ); %LS weights from sigma

roots = BesselJ_RootsCyl();

bs = GetB_Values(protocol)';
idxDW = (bs~=0);

[BasisDirFocused,nDir,xs_intra,nCom_intra,ds_extra,nComExtra,dIso,nIsoComp,X_dt] = setParamsDBFChallenge2015(protocol,idxDW,fibreDir);
DBFs_tot = createDBF_intra_extra_iso_Chall2015(BasisDirFocused,xs_intra,nCom_intra,ds_extra,nComExtra,dIso,nIsoComp,X_dt,S0_per_TE,roots,idxDW,nDir,protocol);


%figure(500); 
%plot3(BasisDirFocused(:,1),BasisDirFocused(:,2),BasisDirFocused(:,3),'k+'); hold on; plot3(1,0,0,'r+'); plot3(0,1,0,'g+'); plot3(0,0,1,'b+'); plot3(fibreDir(1,1),fibreDir(2,1),fibreDir(3,1),'m+');

options = optimset('lsqnonneg');
optnew = optimset(options,'Display','off');

Ws_matrix = repmat(Ws(idxDW),1,size(DBFs_tot,2));
Ws_DBFs_tot = DBFs_tot .* Ws_matrix;
Ws_meas = meas .* Ws;

[alphas, RESNORM,~,EXITFLAG_OPT] = lsqnonneg(Ws_DBFs_tot,Ws_meas(idxDW));



S_dbf = DBFs_tot * alphas; % signal reconstruction
%t = meas; % temp for signal generation
t = S0_per_TE;
t(idxDW) = S_dbf; 
S_dbf = t;



idxOn = find(alphas > 0.005);

alphas_i_On = alphas;
alphas_i_On( setdiff(1:length(alphas),idxOn )) = 0;
RESNORM_On = norm(DBFs_tot*alphas_i_On - meas(idxDW) )^2;

idxOnAniso = idxOn( idxOn <= (nCom_intra+nComExtra)*nDir );
idxOnAniso_intra = idxOnAniso( idxOn <= nCom_intra*nDir );
idxOnAniso_extra = setdiff( idxOnAniso, idxOnAniso_intra ) ;

idxOnIso   = idxOn( idxOn  > (nCom_intra+nComExtra)*nDir & idxOn ~= size(DBFs_tot,2) ); % remove dot

idxOrient = mod(idxOnAniso-1,nDir)+1;

dirsOn = BasisDirFocused(idxOrient,:); % all dirs, separate latter intra and extra

%figure(500); 
%hold on; plot3(dirsOn(:,1),dirsOn(:,2),dirsOn(:,3),'k^'); 
%axis equal;


idx_confs_intra = ceil(idxOnAniso_intra /  nDir); % idx of confs , without the basis direc idx
idx_confs_extra = ceil(idxOnAniso_extra /  nDir) - nCom_intra; % idx of confs , without the basis direc idx
idx_confs_iso = idxOnIso - (nCom_intra+nComExtra)*nDir;

% format long g
% 
% xs_intra(:,idx_confs_intra) % intra used confs
% ds_extra(:,idx_confs_extra) % extra used confs
% 
% dIso(idx_confs_iso) % used dIsos
% 
% 
% 
% 
% RESNORM



end
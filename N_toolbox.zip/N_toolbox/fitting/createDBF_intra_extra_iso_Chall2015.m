function DBFs_tot = createDBF_intra_extra_iso_Chall2015(BasisDir,xs_intra,nCom_intra,ds_extra,nComExtra,dIso,nIsoComp,X,S0_per_TE,roots,idxDW,nDir,protocol)

global VecLePars;
global VecLePerps;

VecLePars = [];
VecLePerps = [];

DBFs_tot = zeros(sum(idxDW),(nCom_intra+nComExtra)*nDir+nIsoComp+1) ; %+ 1 for Dot

for i=1:nCom_intra

    DBFs = createDBF_challenge2015_DifTE( BasisDir, protocol,xs_intra(:,i),roots);
    DBFs_tot(: , (1:nDir)+(i-1)*nDir ) =  DBFs;

end


for i=1:nComExtra

    DBFsExtra = createDBF_bs( ds_extra(1,i), ds_extra(2,i), BasisDir, size(X,1)  ,X);
    
    DBFs_tot(: , nCom_intra*nDir+(1:nDir)+(i-1)*nDir ) =  DBFsExtra;
end


for i=1:nIsoComp
    Eiso = SynthMeasIsoGPD(dIso(i), protocol);
    DBFs_tot(: , (nCom_intra+nComExtra)*nDir+i ) =  Eiso(idxDW);
end


S0_per_TE_matrix = repmat(S0_per_TE(idxDW),1,(nCom_intra+nComExtra)*nDir+nIsoComp+1);
DBFs_tot = DBFs_tot .* S0_per_TE_matrix;

DBFs_tot(:,(nCom_intra+nComExtra)*nDir+nIsoComp+1) = 1;  % dot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end
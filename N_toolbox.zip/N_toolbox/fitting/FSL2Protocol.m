function protocol = FSL2Protocol(bvalfile, bvecfile)
%
% function protocol = FSL2Protocol(bvalfile, bvecfile)
%
% Note: for NODDI, the exact sequence timing is not important.
%  this function reverse-engineerings one possible sequence timing
%  given the b-values.
%
% author: Gary Hui Zhang (gary.zhang@ucl.ac.uk)
%

protocol.pulseseq = 'PGSE';
protocol.schemetype = 'multishellfixedG';
protocol.teststrategy = 'fixed';

% load bval
bval = double(int32(load(bvalfile)));
if size(bval,2)>1
    bval = bval';
end

% set total number of measurements
protocol.totalmeas = length(bval);

% set the b=0 indices
%protocol.b0_Indices = find(bval==0);
protocol.b0_Indices = find(bval<=25); % para datos INB rat 1, bvalue = 18.x


protocol.numZeros = length(protocol.b0_Indices);

%bval = [bval(1:320); round(bval(321:820)/100)*100; round(bval(821:end)/1000)*1000];

idx_B_700 = find( abs(bval - 700.0) < 100);  
idx_B_1000 = find( abs(bval - 1000.0) < 100);  
idx_B_2000 = find( abs(bval - 2000.0) < 100);  

bval(idx_B_700) = mean(bval(idx_B_700));
bval(idx_B_1000) = mean(bval(idx_B_1000));
bval(idx_B_2000) = mean(bval(idx_B_2000));

% find the unique non-zero b-values
%B = unique(bval(bval>0));
B = unique(bval(bval>25)); % para datos INB rat 1, bvalue = 18.x

% set the number of shells
protocol.M = length(B);
for i=1:length(B)
    protocol.N(i) = length(find(bval==B(i)));
end


% maximum b-value in the s/mm^2 unit
maxB = max(B);
GAMMA = 2.675987E8;


% % set maximum G = 40 mT/m
% Gmax = 0.04;
% 
% % set smalldel and delta and G
% tmp = nthroot(3*maxB*10^6/(2*GAMMA^2*Gmax^2),3);
% for i=1:length(B)
%     protocol.udelta(i) = tmp;
%     protocol.usmalldel(i) = tmp;
%     protocol.uG(i) = sqrt(B(i)/maxB)*Gmax;        
% end

%Para datos rat05 - 09
% set maximum G = 40 mT/m
%Gmax = 0.6673001164;
% set smalldel and delta and G
%tmp = nthroot(3*maxB*10^6/(2*GAMMA^2*Gmax^2),3);
gmr = 2*pi*42.576*1e6;
for i=1:length(B)
    protocol.udelta(i) = 0.010;
    protocol.usmalldel(i) = 0.0031;
    protocol.uG(i) = sqrt( B(i)*1e6/ ( (protocol.udelta(i)-protocol.usmalldel(i)/3)*gmr^2*protocol.usmalldel(i)^2  ) );        
end


protocol.delta = zeros(size(bval))';
protocol.smalldel = zeros(size(bval))';
protocol.G = zeros(size(bval))';

for i=1:length(B)
    tmp = find(bval==B(i));
    for j=1:length(tmp)
        protocol.delta(tmp(j)) = protocol.udelta(i);
        protocol.smalldel(tmp(j)) = protocol.usmalldel(i);
        protocol.G(tmp(j)) = protocol.uG(i);
    end
end

% load bvec
bvec = load(bvecfile);
if size(bvec,2)>3
    bvec = bvec';
end
protocol.grad_dirs = bvec;

% make the gradient directions for b=0's [1 0 0]
for i=1:length(protocol.b0_Indices)
    protocol.grad_dirs(protocol.b0_Indices(i),:) = [1 0 0];
end

% make sure the gradient directions are unit vectors
for i=1:protocol.totalmeas
    protocol.grad_dirs(i,:) = protocol.grad_dirs(i,:)/norm(protocol.grad_dirs(i,:));
end




if ~isempty(idx_B_700) 
    protocol.dti_subset = [protocol.b0_Indices ; idx_B_700];
end




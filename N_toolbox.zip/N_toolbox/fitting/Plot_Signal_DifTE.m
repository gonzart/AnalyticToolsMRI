function Plot_Signal_DifTE(S,protocol,fibredir,h,style)

if(nargin<4)
    h = figure;
end


if(nargin<5)
    style = '';
end


linedef{1} = ['b', style];
linedef{2} = ['g', style];
linedef{3} = ['m', style];
linedef{4} = ['c', style];
linedef{5} = ['k', style];
linedef{6} = ['y', style];
linedef{7} = ['r', style];

Snormdw = S; %./b0;

cols = min(6,length(protocol.uG)+1);
rens = ceil(length(protocol.uG)/cols);


for j=1:length(protocol.uG)

    inds = find(protocol.G == protocol.uG(j) & protocol.delta == protocol.udelta(j) & protocol.smalldel == protocol.usmalldel(j));
    dps = abs(protocol.grad_dirs(inds,:)*fibredir);
    [t tinds] = sort(dps);
    subplot(rens,cols,j); hold on;
    plot(dps(tinds), Snormdw(inds(tinds)), linedef{mod(j-1,7)+1}, 'LineWidth', 1);
    hold off;
end
xlabel('|n.G|/|G|_{max}');
%ylabel('S/S_0');
ylabel('S');



end

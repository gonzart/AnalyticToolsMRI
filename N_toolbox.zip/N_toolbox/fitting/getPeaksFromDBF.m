function [npeaks, dir_peaks, w_peaks ,pred_DBF_S_max ,loglikDBF_peak_max ,...
    n_alphas_max, alphas_peaks , idx_Peaks ,  di_max, DBFsFoc_max, alpha_iso] ...
    = getPeaksFromDBF(meas,protocol,BasisDir,dis,sig)


    lambda = 100000*sig;

    bs = GetB_Values(protocol)';
    idxB0 = (bs==0);
    idxDW = (bs~=0);
    
    orientations = protocol.grad_dirs(idxDW,:);


    S0r = mean(meas(idxB0));
    Si = meas(idxDW);

    quality_max = -1e30;   di_max = -1; alphas_max = []; DBFsFoc_max=[]; % initialization

    found = 0;
    for di=dis
        
        [DBFsFoc, idxAnisotropic,idxIsotropic]= createDBF_NODDI_SticksBall(BasisDir, orientations,protocol,di,0,0);

        %Solving DBF
        A = S0r*DBFsFoc;
        alphas_i  = lsqnonneg(A,Si);

        n_alphas_i = sum(alphas_i(idxAnisotropic) > 0.025);        
        pred_DBF_S_i        = meas; pred_DBF_S_i(idxDW) = A*alphas_i;
        loglikDBF_i = RicianLogLik(meas, pred_DBF_S_i, sig);
        quality_i = loglikDBF_i - lambda*n_alphas_i; % 1000 before
        
        if quality_i > quality_max && n_alphas_i >0
                found = 1;
                %fprintf('\n   improving to (%d %.1f)',n_alphas_i,loglikDBF_i);
                n_alphas_max = n_alphas_i;
                quality_max = quality_i;
                di_max = di;
                alphas_max = alphas_i;
                pred_DBF_S_max = pred_DBF_S_i;
                loglikDBF_peak_max = loglikDBF_i;
                DBFsFoc_max = DBFsFoc;
        end
        
    
    end
    
    if found
        alpha_iso = alphas_max(idxIsotropic);
    
        [npeaks, dir_peaks, w_peaks, alphas_peaks, idx_Peaks] = ...
            getDBF_NODDI_peaks_restricted(BasisDir,alphas_max(idxAnisotropic),length(idxAnisotropic));
        
    else
        npeaks = 0;
        dir_peaks=[]; w_peaks=[]; alphas_peaks=[]; idx_Peaks=[]; pred_DBF_S_max=[]; loglikDBF_peak_max=[];
        n_alphas_max=[];  di_max=[]; DBFsFoc_max=[]; alpha_iso =[];
    end
    
%     A = S0r*DBFsFoc_max;        
%     pred_DBF_S_i = meas; 
%     pred_DBF_S_i(idxDW) = A*[alphas_peaks ; alphas_max(size(DBFsFoc_max,2))];
%     seeSignalQlty(meas,pred_DBF_S_i,protocol,dir_peaks(1,:)',S0r); title 'only peaks'    

        
        

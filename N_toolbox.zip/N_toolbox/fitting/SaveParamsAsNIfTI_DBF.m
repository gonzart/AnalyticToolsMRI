function SaveParamsAsNIfTI_DBF(paramsfile, roifile, targetfile, outputpref,clean,percentageBiggest)
%
% function SaveParamsAsNIfTI(paramsfile, roifile, targetfile, outputpref)
%
% author: Gary Hui Zhang (gary.zhang@ucl.ac.uk)
%

% load the fitting results
fprintf('loading the fitted parameters from : %s\n', paramsfile);
load(paramsfile);

% load the roi file
fprintf('loading the roi from : %s\n', roifile);
load(roifile);

% load the target volume
fprintf('loading the target volume : %s\n', targetfile);
target = nifti(targetfile);
xsize = target.dat.dim(1);
ysize = target.dat.dim(2);
if length(target.dat.dim) == 2
    zsize = 1;
else
    zsize = target.dat.dim(3);
end
%total = xsize*ysize*zsize;

% determine the volumes to be saved

fa_vol = zeros(xsize,ysize,zsize);
md_vol = zeros(xsize,ysize,zsize);
DT_Coeffs_vol = zeros(xsize,ysize,zsize,1,6);
DT_PDD_vol = zeros(xsize,ysize,zsize,3);
l1_vol = zeros(xsize,ysize,zsize);
l2_vol = zeros(xsize,ysize,zsize);
l3_vol = zeros(xsize,ysize,zsize);

mask_fitDBF_vol = zeros(xsize,ysize,zsize);

nTen_vol = zeros(xsize,ysize,zsize);
fPDD_vol = zeros(xsize,ysize,zsize,3,3);
sizeCompart_vol = zeros(xsize,ysize,zsize,3);
tensors1 = zeros(xsize,ysize,zsize,1,6);
tensors2 = zeros(xsize,ysize,zsize,1,6);
tensors3 = zeros(xsize,ysize,zsize,1,6);

T = [meanL1 0 0 ; 0 meanL2 0; 0 0 meanL2];

for i=1:size(fa,1)
    fa_vol(idx(i,1),idx(i,2),idx(i,3)) = fa(i);
    md_vol(idx(i,1),idx(i,2),idx(i,3)) = MDs(i);
    DT_Coeffs_vol(idx(i,1),idx(i,2),idx(i,3),1,:) = DTs(i,:);
    DT_PDD_vol(idx(i,1),idx(i,2),idx(i,3),:) = DT_PDD(i,:);
    
    l1_vol(idx(i,1),idx(i,2),idx(i,3)) = lambdas(i,1);
    l2_vol(idx(i,1),idx(i,2),idx(i,3)) = lambdas(i,2);
    l3_vol(idx(i,1),idx(i,2),idx(i,3)) = lambdas(i,3);
    
    
    if idxfitDBF(i)== false
        continue;
    end
    
    mask_fitDBF_vol(idx(i,1),idx(i,2),idx(i,3)) = double(idxfitDBF(i));
    
    nTen_vol(idx(i,1),idx(i,2),idx(i,3)) = 1;
    
    nAmount = fAmountDiff(i,:);
    [~,idxMax] = max(nAmount);
    
    direc = squeeze(fPDD(i,idxMax,:));
    
    mtx = fromToRotation([1 ;0 ;0], direc);
    Ti = mtx * T * mtx';
    
    Ti = Ti * fAmountDiff(i,idxMax); % for Gary's visor
    
    tensors1(idx(i,1),idx(i,2),idx(i,3),1,1)= Ti(1,1);
    tensors1(idx(i,1),idx(i,2),idx(i,3),1,2)= Ti(2,1);
    tensors1(idx(i,1),idx(i,2),idx(i,3),1,3)= Ti(2,2);
    tensors1(idx(i,1),idx(i,2),idx(i,3),1,4)= Ti(3,1);
    tensors1(idx(i,1),idx(i,2),idx(i,3),1,5)= Ti(3,2);
    tensors1(idx(i,1),idx(i,2),idx(i,3),1,6)= Ti(3,3);
    
    fPDD_vol(idx(i,1),idx(i,2),idx(i,3),1,:) = fPDD(i,idxMax,:);
    sizeCompart_vol(idx(i,1),idx(i,2),idx(i,3),1) = fAmountDiff(i,idxMax);
    
    if fNDiff(i)>1
        
        nAmount(idxMax) = 0;
        [~,idx2] = max(nAmount);
        
        if clean && fAmountDiff(i,idx2) > fAmountDiff(i,idxMax)*percentageBiggest
            nTen_vol(idx(i,1),idx(i,2),idx(i,3)) = 2;
            
            direc = squeeze(fPDD(i,idx2,:));
            
            
            mtx = fromToRotation([1 ;0 ;0], direc);
            Ti = mtx * T * mtx';
            Ti = Ti * fAmountDiff(i,idx2); % for Gary's visor
            
            tensors2(idx(i,1),idx(i,2),idx(i,3),1,1)= Ti(1,1);
            tensors2(idx(i,1),idx(i,2),idx(i,3),1,2)= Ti(2,1);
            tensors2(idx(i,1),idx(i,2),idx(i,3),1,3)= Ti(2,2);
            tensors2(idx(i,1),idx(i,2),idx(i,3),1,4)= Ti(3,1);
            tensors2(idx(i,1),idx(i,2),idx(i,3),1,5)= Ti(3,2);
            tensors2(idx(i,1),idx(i,2),idx(i,3),1,6)= Ti(3,3);
            
            fPDD_vol(idx(i,1),idx(i,2),idx(i,3),2,:) = fPDD(i,idx2,:);
            sizeCompart_vol(idx(i,1),idx(i,2),idx(i,3),2) = fAmountDiff(i,idx2);
            
        end
        
    end
    
    if fNDiff(i)>2
        
        
        nAmount(idx2) = 0;
        [~,idx3] = max(nAmount);
        
        
        if clean && fAmountDiff(i,idx3) > fAmountDiff(i,idxMax)*percentageBiggest
            
            nTen_vol(idx(i,1),idx(i,2),idx(i,3)) = 3;
            
            direc = squeeze(fPDD(i,idx3,:));
            
            
            mtx = fromToRotation([1 ;0 ;0], direc);
            Ti = mtx * T * mtx';
            Ti = Ti * fAmountDiff(i,idx3); % for Gary's visor
            
            tensors3(idx(i,1),idx(i,2),idx(i,3),1,1)= Ti(1,1);
            tensors3(idx(i,1),idx(i,2),idx(i,3),1,2)= Ti(2,1);
            tensors3(idx(i,1),idx(i,2),idx(i,3),1,3)= Ti(2,2);
            tensors3(idx(i,1),idx(i,2),idx(i,3),1,4)= Ti(3,1);
            tensors3(idx(i,1),idx(i,2),idx(i,3),1,5)= Ti(3,2);
            tensors3(idx(i,1),idx(i,2),idx(i,3),1,6)= Ti(3,3);
            
            fPDD_vol(idx(i,1),idx(i,2),idx(i,3),3,:) = fPDD(i,idx3,:);
            sizeCompart_vol(idx(i,1),idx(i,2),idx(i,3),3) = fAmountDiff(i,idx3);
        end
        
    end
    
    %normalize sizecompartments
    sumSC = sum(sizeCompart_vol(idx(i,1),idx(i,2),idx(i,3),:));
    if sumSC>0
        sizeCompart_vol(idx(i,1),idx(i,2),idx(i,3),:) = sizeCompart_vol(idx(i,1),idx(i,2),idx(i,3),:) / sumSC;
    end
end

% save as NIfTI
fprintf('Saving the volumetric maps of the fitted parameters ...\n');

niftiSpecs.dim = [xsize ysize zsize];
niftiSpecs.mat = target.mat;
niftiSpecs.mat_intent = target.mat_intent;
niftiSpecs.mat0 = target.mat0;
niftiSpecs.mat0_intent = target.mat0_intent;

output = ['DT_FA_' outputpref '.nii'];
SaveAsNIfTI(fa_vol, niftiSpecs, output);

output = ['DT_MD_' outputpref '.nii'];
SaveAsNIfTI(md_vol, niftiSpecs, output);

output = ['nTens_' outputpref '.nii'];
SaveAsNIfTI(nTen_vol, niftiSpecs, output);

output = ['mask_fitDBF_' outputpref '.nii'];
SaveAsNIfTI(mask_fitDBF_vol, niftiSpecs, output);

output = ['DT_L1_' outputpref '.nii'];
SaveAsNIfTI(l1_vol, niftiSpecs, output);

output = ['DT_L2_' outputpref '.nii'];
SaveAsNIfTI(l2_vol, niftiSpecs, output);

output = ['DT_L3_' outputpref '.nii'];
SaveAsNIfTI(l3_vol, niftiSpecs, output);


niftiSpecs.dim = [xsize ysize zsize 3];
output = ['DT_PDD_' outputpref '.nii'];
SaveAsNIfTI(DT_PDD_vol, niftiSpecs, output);

%volRGB = uint8(abs(squeeze(DT_PDD_vol(:,:,17,:)))*255)
%figure; imshow(volRGB)

niftiSpecs.dim = [xsize ysize zsize 1 6];

output = ['DT_Coeffs_' outputpref '.nii'];
SaveAsNIfTI(DT_Coeffs_vol, niftiSpecs, output);



output = ['tensors1_' outputpref '.nii'];
SaveAsNIfTI(tensors1, niftiSpecs, output);

output = ['tensors2_' outputpref '.nii'];
SaveAsNIfTI(tensors2, niftiSpecs, output);

output = ['tensors3_' outputpref '.nii'];
SaveAsNIfTI(tensors3, niftiSpecs, output);


niftiSpecs.dim = [xsize ysize zsize 3 3];

output = ['fPDD_' outputpref '.nii'];
SaveAsNIfTI(fPDD_vol, niftiSpecs, output);


niftiSpecs.dim = [xsize ysize zsize 3];

output = ['fAmountDiff_' outputpref '.nii'];
SaveAsNIfTI(sizeCompart_vol, niftiSpecs, output);

fp = fopen(['DBF_params_' outputpref '.dat'],'w');
fprintf(fp,'%.15f \n%.15f',meanL1,meanL2);
fclose(fp);

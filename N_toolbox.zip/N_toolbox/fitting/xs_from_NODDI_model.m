function xs = xs_from_NODDI_model()

    n_inc = 5;
    
    x2_ini = 2.08; % toke it from histograms
    x2_fin = 2.46;
    x2_vs = (x2_ini:(x2_fin-x2_ini)/(n_inc-1):x2_fin) * 1e-9;
    
    x3_ini = 0.223; % toke it from histograms
    x3_fin = 0.808;
    x3_vs = (x3_ini:(x3_fin-x3_ini)/(n_inc-1):x3_fin) * 1e-9;
    
    x4_ini = 0.819; % toke it from histograms
    x4_fin = 3.25;
    x4_vs = (x4_ini:(x4_fin-x4_ini)/(n_inc-1):x4_fin) * 10;

    
    xs = combvec(x2_vs,x3_vs,x4_vs);
    xs = [zeros(1,size(xs,2)) ; xs ; zeros(1,size(xs,2)) ; ones(1,size(xs,2))*3e-9 ; ones(1,size(xs,2))*0.0506]; % the last is 'irfrac'
    

% 
%         %x(1) = 0.5; %0.4236; %is the volume fraction of the intracellular space. JUST NEEDED TO PROPOSE dPerp
%         x(2) = 2.31e-9; %2.2e-9; %3e-9; %1.7e-9; %is the free diffusivity of the material inside and outside the cylinders. fixed
%         x(3) = 0.5048e-9; %0.65e-9; %0.1171e-9; % is d hindered
%         x(4) = 2.06*10; %1.96*1e1; %16; %0.4058; %is the concentration parameter of the Watson's distribution. fixed, or maybe 16 and 32
%         %x(5) = 0.2; %is the volume fraction of the isotropic compartment.
%         x(6) = 3e-9; %is the diffusivity of the isotropic compartment. fixed
%         x(7) = 0.0506; %0.035; %'irfrac';
%         %x(8) = 1; %is the measurement at b=0.
end
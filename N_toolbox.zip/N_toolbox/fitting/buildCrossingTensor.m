function [T1, T2, d1, d2] = buildCrossingTensor(angle,d_long1,d_radi1,d_long2,d_radi2)





    %%%%%%%%%%%%%%%%%%%%%%%%%%%

    T1 = diag([d_long1 d_radi1 d_radi1]);    
    T2 = diag([d_long2 d_radi2 d_radi2]);


    d1 = [1 0 0]';
    
    d2 = [cos(angle) sin(angle) 0]';

    A = rand(3,3); A = A*A'; [RotAlea, ~] = eig(A);
    d1 = RotAlea * d1;
    d2 = RotAlea * d2;
    
    %d1'
    %d2'
    
    R = fromToRotation([1; 0; 0], d1);
    T1 = R*T1*R';

       
    R = fromToRotation([1; 0; 0], d2);
    T2 = R*T2*R';

end
%FORWARD Forward substitution for 4x4 lower triangular systems
% Written by <YOUR NAME> on <TODAY?S DATE>
function x = forward( A, b )
N = size(A,1);
x = zeros(N,1);
x(1) = b(1)/A(1,1);
for i = 2:1:N, % i starts at 2, end at 4, w/ steps of 1
    x(i) = (b(i)-A(i,1:i-1)*x(1:i-1))/A(i,i);
end

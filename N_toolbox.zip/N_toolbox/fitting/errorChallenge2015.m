function err = errorChallenge2015(meas,synth,sig_per_TE)

    err = sum( ( meas - sqrt(synth.^2 + sig_per_TE.^2 ) ).^2  ./ sig_per_TE.^2 );
end
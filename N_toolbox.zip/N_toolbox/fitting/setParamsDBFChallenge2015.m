function [BasisDirFocused,nDir,xs_intra,nCom_intra,ds_extra,nComExtra,dIso,nIsoComp,X_dt] = setParamsDBFChallenge2015(protocol,idxDW,fibreDir)

path_data = '/Users/alram/Dropbox/matlabs/data/NODDI_example_dataset/';
%DBFDirectionsFileName = [path_data 'DBF_129orientations.dat'];
DBFDirectionsFileName = [path_data 'PuntosElectroN1000.txt'];
BasisDirHR = load(DBFDirectionsFileName);
BasisDirHR(BasisDirHR(:,1)<0,:) = -BasisDirHR(BasisDirHR(:,1)<0,:);

BasisDirFocused = [];
for i=1:size(fibreDir,2)
    BasisDirFocused = [ BasisDirFocused ; neighFromDirects(BasisDirHR,fibreDir(:,i)',120,1) ; fibreDir(:,i)']; % 120
end
BasisDirFocused = unique(BasisDirFocused,'rows'); % remove repetitions

%BasisDirFocused = fibreDir';


% DBFDirectionsFileName = [path_data 'PuntosElectroN10000.txt'];
% BasisDirHR = load(DBFDirectionsFileName);
% BasisDirHR(BasisDirHR(:,1)<0,:) = -BasisDirHR(BasisDirHR(:,1)<0,:);
% 
% BasisDirFocused = [ BasisDirFocused ; neighFromDirects(BasisDirHR,fibreDir',30,1) ];


nDir = size(BasisDirFocused,1) ;

fprintf( 'max angle disp = %f', double(max(sort(acos(abs(BasisDirFocused*fibreDir(:,1)))*180/pi))) );


%test generate signal intra axonal
x2 = (1.0:0.1:2.1)*1e-9; % di 
x3 = (0:1:12)*1e-6; % the radius of the axons
 
% extra celular space
di = (1.0:0.1:2.5)*1e-9; % di 
dp = (1.7/7:0.1:1.7/2)*1e-9; % radial diff
 
% isotropic compartments
dIso = (2.0:0.1:4.0)*1e-9; % diso, 
% dIso = [];

xs_intra = combvec(x2,x3);
nCom_intra = size(xs_intra,2);

ds_extra = combvec(di,dp);
nComExtra = size(ds_extra,2);


nIsoComp = length(dIso);


X_dt = DT_DesignMatrix(protocol);
X_dt = X_dt(idxDW,2:end);

end

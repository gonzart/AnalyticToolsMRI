function [anisDBF vecsDisp]= anisotropicDBF(BasisDir, protocol,di,np_r, close_neigh, idx_Peaks, DBFs)

    bs = GetB_Values(protocol)';
    idxDW = (bs~=0);
    bs = bs(idxDW);

    nRotations = 72*2;
    angle = pi/nRotations;
    
    
    anisDBF = [];
    vecsDisp = [];
    
    n = size(close_neigh,2);
    for i=1:np_r
        for k=1:n
            idx = close_neigh(idx_Peaks(i),k);
            dir = BasisDir(idx,:)';
            
            [dbf vecdisp] = rotationalBasis(dir,nRotations,angle,protocol,di,bs,idxDW);
            
            anisDBF = [anisDBF dbf];
            vecsDisp = [vecsDisp;vecdisp];
        end
    end
    
    for i=1:np_r
        
        anisDBF = [anisDBF DBFs(:,idx_Peaks(i))];
    end    
    % get signal from iso compartment
    dIso = 2e-9;
    Eiso = SynthMeasIsoGPD(dIso, protocol);
    anisDBF = [ anisDBF Eiso(idxDW)];
    
    

    
end


function tuneBValue

    clc
    clear
    close all
    

    GAMMA = 2.675987E8;

    G=0.280; 
    %G=0.425; 
    smalldel =0.0015; 
    delta =0.070; 
    modQ = GAMMA*smalldel*G; 
    diffTime = delta - smalldel/3; 
    b = diffTime.*modQ.^2


    % en el simulador de MC
    %duration 0.072
    
    

    S0 = 500000;
    S = 339138;

    D_real= 0.45e-9;

    D_est = -log(S/S0)/b

    err = abs(D_est-D_real)/D_real

end
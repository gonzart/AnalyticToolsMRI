function E = SynthMeasWatsonSHCylSingleRadTortIsoV_GPD_B0_DifTE(meas,x, protocol, fibredir, roots)

%B0 = x(7);
x(7) = 1;

E = SynthMeasWatsonSHCylSingleRadTortIsoV_GPD_B0(x, protocol, fibredir, roots);

% if isfield(protocol, 'TE') 
%     for i=1:length(protocol.uTE)
%         idxB0 = intersect ( find(protocol.TE == protocol.uTE(i)),protocol.b0_Indices);
%         S0_TE = mean(meas(idxB0));
%         idxDW = find(protocol.TE == protocol.uTE(i));
%         E(idxDW) =  E(idxDW) * S0_TE;
%     end
%     
% else 
%     E = B0 * E; 
% end
function [Ssynth, alphas_GT,sigmaEmpiric_per_TE,S_GT] = synthSignal_Challenge2015(meas,protocol,fibreDir)

    roots = BesselJ_RootsCyl();

    bs = GetB_Values(protocol)';
    idxDW = (bs~=0);

    [S0_per_TE, sigmaEmpiric_per_TE] = compute_S0_per_TE(protocol,meas);
    sig_per_TE = sigmaFromB0_difTE(S0_per_TE,protocol);
    
    %sigmaEmpiric_per_TE = sigmaEmpiric_per_TE;
    
    [BasisDirFocused,nDir,xs_intra,nCom_intra,ds_extra,nComExtra,dIso,nIsoComp,X_dt] = setParamsDBFChallenge2015(protocol,idxDW,fibreDir);
    DBFs_tot = createDBF_intra_extra_iso_Chall2015(BasisDirFocused,xs_intra,nCom_intra,ds_extra,nComExtra,dIso,nIsoComp,X_dt,S0_per_TE,roots,idxDW,nDir,protocol);

    alphas_GT = double(rand(size(DBFs_tot,2),1)>0.99);
    
    alphas_GT = alphas_GT / sum(alphas_GT);
    
    S_GT = DBFs_tot * alphas_GT;
    
    t = S0_per_TE;
    t(idxDW) = S_GT; 
    S_GT = t;
    
    
    %add noise
    
    SNoisy = sqrt(  (S_GT+randn(size(S_GT)).*sig_per_TE).^2 + (randn(size(S_GT)).*sig_per_TE).^2 );
    SNoisy_empiric = sqrt(  (S_GT+randn(size(S_GT)).*sigmaEmpiric_per_TE).^2 + (randn(size(S_GT)).*sigmaEmpiric_per_TE).^2 );
    
    
   h = figure; VoxelDataViewer_DifTE(protocol, meas, fibreDir, h);
   seeSignalQlty_DifTE(SNoisy,meas,protocol,fibreDir(:,1)); %title 'S NODDI'
   seeSignalQlty_DifTE(SNoisy_empiric,meas,protocol,fibreDir(:,1)); %title 'S NODDI'

   seeSignalQlty_DifTE(SNoisy,S_GT,protocol,fibreDir(:,1)); %title 'S NODDI'
   seeSignalQlty_DifTE(SNoisy_empiric,S_GT,protocol,fibreDir(:,1)); %title 'S NODDI'
   
   
   
   Ssynth = SNoisy_empiric;
    
end
function G = gValFromOthers(DELTA,delta,bval)
    %Definir gyromagnetic ratio:
    gmr = 2*pi*42.576*1e6; %de MHZ/T ->  rad/(sec T)

    G = sqrt(bval/(gmr^2 * delta.^2 .* (DELTA-delta/3)));  % en s/m^2
end

function [sig_per_TE , factEval_per_TE]= sigmaFromB0_difTE(S0_per_TE,protocol)

    m = (6-35)/((152 - 49)*1e-3); %pendiente del modelo lineal dados los 2 puntos en el web site
    SNRs = m*(protocol.uTE-49*1e-3) + 35; 
    
    sig_per_TE= zeros(size(S0_per_TE));
    factEval_per_TE= zeros(size(S0_per_TE));
    epsilon = 10;
    for i=1:length(protocol.uTE)
       idx = (protocol.TE ==  protocol.uTE(i));
       sig_per_TE(idx) = S0_per_TE(idx) / SNRs(i);
       
       sign = rand(1,1)*2 -1; sign = sign / abs(sign);
       factEval_per_TE(idx) = ( (S0_per_TE(idx)+epsilon*sign) - sqrt ( S0_per_TE(idx).^2 + sig_per_TE(idx).^2) ).^2  ./  sig_per_TE(idx).^2 ;
       
    end
    
    
    

end
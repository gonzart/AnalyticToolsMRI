function fitTensorFromMC

 

    %set fibre direction

    fibredir = [0;0;1];

 

    %read protocol

    my_scheme_file = 'file.scheme';

    [bval , bvec ,G ,delta ,DELTA , TE  ]=readChallenge2015ProtocolData('/home/user/Dropbox/datosEPFL/simulations/schemes/',my_scheme_file);

    protocol = Challenge2015_2_Protocol(bval , bvec ,G ,delta ,DELTA ,TE ); 

 

    %read Signal file

    my_file = [  my_data_name_file '_DWI.txt'];

    S_MC = load([my_path '/outputs/' my_file]);

 

    % get the mean S0 value

    S0 = mean(S_MC(protocol.b0_Indices));

    

 

    %normalize signal

    S_MC = S_MC ./ S0;

 

    % see the signal (the same (unique signal 2 times)

    %seeSignalQlty(S_MC,S_MC,protocol,fibredir,S0);

    

    

    % Fit a tensor

    D = FitLinearDT(S_MC, protocol);

 

    % get eigen values

    eigsVals = getEigenVals(D)

 

 

end
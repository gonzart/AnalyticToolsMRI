function S_out = newSignalForProtocol(S0_per_TE,protocol,protocol_out,roots,fibredir,alphas)

    S0_per_TE_out = computeS0_per_TE_fromMeas(S0_per_TE,protocol,protocol_out);
    
    bs_out = GetB_Values(protocol_out)';
    idxDW_out = (bs_out~=0);
    
    
    [BasisDirFocused,nDir,xs_intra,nCom_intra,ds_extra,nComExtra,dIso,nIsoComp,X_dt] = setParamsDBFChallenge2015(protocol_out,idxDW_out,fibredir);
    DBFs_tot_out = createDBF_intra_extra_iso_Chall2015(BasisDirFocused,xs_intra,nCom_intra,ds_extra,nComExtra,dIso,nIsoComp,X_dt,S0_per_TE_out,roots,idxDW_out,nDir,protocol_out);

    
    
    S_out = DBFs_tot_out * alphas; % signal reconstruction
    t = S0_per_TE_out; % temp for signal generation
    t(idxDW_out) = S_out;

    S_out = t;
end
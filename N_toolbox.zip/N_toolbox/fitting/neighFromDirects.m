function close_neigh_dirs = neighFromDirects(BasisDir,directs,n,m)

    %m = size(directs,1);
    close_neigh_dirs = [];
    
    for i = 1:m
       dots = abs(BasisDir * directs(i,:)');
       
       [vs idx] = sort(dots,1,'descend');
       
       newDirec = BasisDir(idx(1:n),:);
       
%        %remove very similar from HRD
%        for k=1:m
%             correlacion = directs(k,:)*newDirec';
%             diferentes = abs(correlacion) < cos(2.25*pi/180);
%             newDirec = newDirec(diferentes,:);
%        end
       
%       close_neigh_dirs = [close_neigh_dirs ; directs(i,:) ; newDirec ];
       close_neigh_dirs = [close_neigh_dirs  ; newDirec ];
       
    end
    
    
%     correlacion = abs(close_neigh_dirs * close_neigh_dirs');
%     iguales = abs(correlacion) >= cos(pi/180);
%     [is,js] = find(iguales);
%     
%     [vals idsxs]=sort(is);
%     is = vals; js = js(idsxs);
% 
%     ni = size(is,1);
%     idxRep = [];
%     
%     for k=1:ni
%         if js(k) > is(k)
%             %fprintf('\n %d-(%f %f %f) es repetido de %d-(%f %f %f)',js(k),close_neigh_dirs(js(k),:),is(k),close_neigh_dirs(is(k),:));
%             idxRep = [idxRep ; js(k) ];
%         end
%     end
%     
%     close_neigh_dirs = close_neigh_dirs(setdiff(1:size(close_neigh_dirs,1),idxRep),:);
    
    
end


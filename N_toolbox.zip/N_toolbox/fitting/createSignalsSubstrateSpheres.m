function [S_tot,Ss_individual,compartmentSizes] = createSignalsSubstrateSpheres(rads,coeff_diff,N_sphere,protocol)
    global VecLePars;
    global VecLePerps;

    VecLePars = [];
    VecLePerps = [];
    
    roots = BesselJ_RootsSphere();
    
    for i=1:N_sphere
        intra_x = [coeff_diff;rads(i)];
        Ss_individual(:,i) = SynthMeasSphereNeuman_PGSE(intra_x, protocol.grad_dirs, protocol.G', protocol.delta', protocol.smalldel', roots);
    end
    compartmentSizes = pi*rads.^2;
    compartmentSizes = compartmentSizes ./ sum(compartmentSizes);
    
    %figure; plot(rads,compartmentSizes);
    
    S_tot = Ss_individual * diag(compartmentSizes);
    S_tot = sum( S_tot, 2);
end
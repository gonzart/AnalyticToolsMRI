function bval = bvalFromOthers(G,DELTA,delta)
    %Definir gyromagnetic ratio:
    gmr = 2*pi*42.576*1e6; %de MHZ/T ->  rad/(sec T)

    bval = gmr^2 * G.^2 .* delta.^2 .* (DELTA-delta/3) ; % en s/m^2
end

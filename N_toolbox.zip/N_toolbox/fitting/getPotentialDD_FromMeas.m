function potentialDir = getPotentialDD_FromMeas(protocol,meas)

    bs = GetB_Values(protocol)';
    %idxB0 = (bs==0);
    idxDW = (bs~=0);
    
    orientations = protocol.grad_dirs(idxDW,:);

    %bsOrientations = bs(idxDW);
    
    W = abs(orientations*orientations'); W(W>1) = 1;
    W = sin(acos(W))*meas(idxDW); % ecuator have big weights
    
    maxV = max(W);
    minV = min(W);
    
    potentialDir = orientations(W >= minV+(maxV-minV)*0.4,:);

end
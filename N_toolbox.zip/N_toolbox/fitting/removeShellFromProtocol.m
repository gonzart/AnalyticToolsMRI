function [protocol_train, meas_train,  protocol_test, meas_test,bval_train, bvec_train,G_train,delta_train,DELTA_train,TE_train,bval_test, bvec_test,G_test,delta_test,DELTA_test,TE_test] ...
    = removeShellFromProtocol(r_unB,r_unDELTA,r_unsmalldelta,r_unG,meas,bval,bvec,G,delta,DELTA,TE)

    idxAllDW_test = [];
    idxAllB0_test = [];
    
    for i=1:length(r_unG)

        idxDW_test = find( r_unB(i) == bval & r_unDELTA(i) == DELTA & r_unsmalldelta(i) == delta & r_unG(i)== G );
        TEshell = unique(TE(idxDW_test) );
        idxB0_test = find( G == 0 & TE == TEshell  ) ;
        
        idxAllDW_test = [idxAllDW_test; idxDW_test];
        idxAllB0_test = [idxAllB0_test; idxB0_test];
    end
    
    idxAll_test = [unique(idxAllB0_test) ; idxAllDW_test];
    
    %fprintf('\n  %.3f %% data for testing \n\n', 100*length(idxAllDW_test) / sum(G~=0) );
    
    meas_test=meas(idxAll_test);bval_test=bval(idxAll_test); bvec_test=bvec(idxAll_test,:); G_test=G(idxAll_test); delta_test=delta(idxAll_test); DELTA_test=DELTA(idxAll_test); TE_test=TE(idxAll_test);
    protocol_test = Challenge2015_2_Protocol(bval_test, bvec_test,G_test,delta_test,DELTA_test,TE_test); % protocol sin B0 ni DW outiers
    
    
    idxAll_train = setdiff(1:length(meas),idxAllDW_test);    
    meas_train=meas(idxAll_train);bval_train=bval(idxAll_train); bvec_train=bvec(idxAll_train,:); G_train=G(idxAll_train); delta_train=delta(idxAll_train); DELTA_train=DELTA(idxAll_train); TE_train=TE(idxAll_train);
    protocol_train = Challenge2015_2_Protocol(bval_train, bvec_train,G_train,delta_train,DELTA_train,TE_train); % protocol sin B0 ni DW outiers
    
    
end
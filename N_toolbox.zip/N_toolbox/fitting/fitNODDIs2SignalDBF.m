function [scFib mls TotalSignal] = fitNODDIs2SignalDBF(np,alphas_a,anisDBF,meas, protocol,idxBoundles,pdds,idxIso,noddi_b)


    bs = GetB_Values(protocol)';
    idxB0 = (bs==0);
    idxDW = (bs~=0);
    

    S0r = mean(meas(idxB0));


    scFib = zeros(1,np);
    mls= [];
    
    TotalSignal = meas;
    TotalSignal(idxDW) = zeros(sum(idxDW),1);
    for i=1:np
        scFib(i) = sum(alphas_a(idxBoundles(i,:)));
        
        SBundle = meas*scFib(i); % S0 is also multiplied
        SBundle(idxDW) = S0r*anisDBF(:,idxBoundles(i,:)) * alphas_a(idxBoundles(i,:));
        
        

        
        myTheta = acos(  pdds(i,3)   );
        myPhi = atan2( pdds(i,2) ,  pdds(i,1) );
        
        %noddi_b.GS.fixedvals(GetParameterIndex(noddi_b.name, 'di')) = di_max; % di is fixed to each particular value
        %noddi_b.GD.fixedvals(GetParameterIndex(noddi_b.name, 'di')) = di_max;        
        noddi_b.GS.fixedvals(GetParameterIndex(noddi_b.name, 'theta')) = myTheta; % angle is fixed to each particular value
        noddi_b.GD.fixedvals(GetParameterIndex(noddi_b.name, 'theta')) = myTheta;
        noddi_b.GS.fixedvals(GetParameterIndex(noddi_b.name, 'phi')) = myPhi; % angle is fixed to each particular value
        noddi_b.GD.fixedvals(GetParameterIndex(noddi_b.name, 'phi')) = myPhi;
        
        [gs_b fgs_b ml_b] = ThreeStageFittingVoxel(SBundle, protocol, noddi_b, 0);
        scale_b = GetScalingFactors(noddi_b.name);
        xsc_b = ml_b(1:(length(scale_b)-1))./scale_b(1:(end-1));
        recoveredFibreDir_b = GetFibreOrientation(noddi_b.name, ml_b);

        S_NODDI_b = SynthMeas(noddi_b.name, xsc_b, protocol, recoveredFibreDir_b, 0); %  * scFib(i);
        TotalSignal(idxDW) = TotalSignal(idxDW) + S_NODDI_b(idxDW);      
        seeSignalQlty(SBundle,S_NODDI_b,protocol,recoveredFibreDir_b,S0r); title 'S S-NODDI-bundle'
        
        mls(1,:) = ml_b;
    end

    % add the isotropic part
    
    TotalSignal(idxDW) = TotalSignal(idxDW) + anisDBF(:,idxIso)*alphas_a(idxIso);


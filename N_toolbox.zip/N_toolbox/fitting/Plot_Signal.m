function Plot_Signal(S,protocol,fibredir,b0,h,style)

if(nargin<5)
    h = figure;
end


if(nargin<6)
    style = '-';
end


linedef{1} = ['r', style];
linedef{2} = ['b', style];
linedef{3} = ['g', style];
linedef{4} = ['m', style];
linedef{5} = ['c', style];
linedef{6} = ['k', style];
linedef{7} = ['y', style];

Snormdw = S./b0;
for j=1:length(protocol.uG)
    inds = find(protocol.G == protocol.uG(j) & protocol.delta == protocol.udelta(j) & protocol.smalldel == protocol.usmalldel(j));
    dps = abs(protocol.grad_dirs(inds,:)*fibredir);
    [t tinds] = sort(dps);
    plot(dps(tinds), Snormdw(inds(tinds)), linedef{mod(j-1,7)+1}, 'LineWidth', 2);
end
xlabel('|n.G|/|G|_{max}');
ylabel('S/S_0');



end


function [DBFs, idxAnisotropic, idxIsotropic] = createDBF_stickAndBall(cosT_b,protocol,idxDW, dp,dIso)



    DBFs = exp(cosT_b*dp);

    nTensoresBase = size(cosT_b,2);

    % get signal from iso compartment
    Eiso = SynthMeasIsoGPD(dIso, protocol);
    DBFs = [DBFs Eiso(idxDW)];

    idxAnisotropic = 1:nTensoresBase;
    idxIsotropic = nTensoresBase+1;

end


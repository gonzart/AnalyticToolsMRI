function [nB, dirB, scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] = ...
    DBF_NODDI_fit(meas,protocol,sig,SNR)

%global Sh1 Sr1 Siso1 Sh2 Sr2
global actualFibreDir1 actualFibreDir2 NGT

path_data = '/home/alram/matlabs/data/NODDI_example_dataset/';
DBFDirectionsFileName = [path_data 'PuntosElectroN500.txt'];
%DBFDirectionsFileName = [path_data 'PuntosElectroN500.txt'];
BasisDir = load(DBFDirectionsFileName);
%nTensoresBase = size(BasisDir,1);

BasisDir(BasisDir(:,3)<0,:) = -BasisDir(BasisDir(:,3)<0,:);


DBFDirectionsFileName = [path_data 'PuntosElectroN5000.txt'];
BasisDirHR = load(DBFDirectionsFileName);
BasisDirHR(BasisDirHR(:,3)<0,:) = -BasisDirHR(BasisDirHR(:,3)<0,:);
x5 = 3.0e-9;
x3 = 20;

%di_max=1.7e-9; % should it be 2.1451? 
    %xs_ini = [0.5; 1.7e-9; 10; 1; 3e-9;1];
    x1 = 0.1:0.2:0.9; % important to propose  dpar
    %x3 = 8:6:20; % dispersion

    
    [nB, dirB, scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] =...
        getBundlesFromDBF(meas,protocol,BasisDir,sig,SNR,x1,x3,0);
    
    if nB==0 ; return; end
    
    x1 = x_max(1)-0.2:0.1:x_max(1)+0.2; x1 = x1( x1>0 & x1<1);% important to propose  dpar
    %x3 = x_max(3)-4:2:x_max(3)+4; x3 = x3( x3>0); % dispersion
    
   
    BasisDirFocused = neighFromDirects(BasisDirHR,dirB,56,nB);
    [nB, dirB,  scB,szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] = ...
        getBundlesFromDBF(meas,protocol,BasisDirFocused,sig,SNR,x1,x3,0);
    if nB==0 ; return; end
% 
%     BasisDirFocused = neighFromDirects(BasisDirHR,dirB,10,nB);
%     [nB, dirB,  scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] = ...
%         getBundlesFromDBF(meas,protocol,BasisDirFocused,sig,SNR,x_max(1),x_max(3));
%     if nB==0 ; return; end
% 
%     BasisDirFocused = neighFromDirects(BasisDirHR,dirB,10,nB);
%     [nB, dirB,  scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] = ...
%         getBundlesFromDBF(meas,protocol,BasisDirFocused,sig,SNR,x_max(1),x_max(3));
%     if nB==0 ; return; end
% 
    x1 = x_max(1)-0.15:0.05:x_max(1)+0.15; x1 = x1( x1>0 & x1<1);% important to propose  dpar
    %x3 = x_max(3)-4:1.5:x_max(3)+4; x3 = x3( x3>0); % dispersion
    BasisDirFocused = neighFromDirects(BasisDirHR,dirB,10,nB);
    [nB, dirB,  scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] = ...
         getBundlesFromDBF(meas,protocol,BasisDirFocused,sig,SNR,x_max(1),x_max(3),0);    
        %getBundlesFromDBF(meas,protocol,BasisDirFocused,sig,SNR,x1,x3,0);    
         
    if nB==0 ; return; end
    
    x1 = x_max(1)-0.1:0.025:x_max(1)+0.1; x1 = x1( x1>0 & x1<1);% important to propose  dpar
    %x3 = x_max(3)-5:1:x_max(3)+5; x3 = x3( x3>0); % dispersion
    BasisDirFocused = neighFromDirects(BasisDirHR,dirB,12,nB);
    %[nB, dirB, scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] = ...
    %    getBundlesFromDBF(meas,protocol,dirB(1:nB,:),sig,SNR,x1,x3);
    [nB, dirB, scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] = ...
        getBundlesFromDBF(meas,protocol,BasisDirFocused,sig,SNR,x1,x3,x5);

    %[nB, dirB, scB, szCh, szCr ,cIso,szCIso,szCDot, predB_S, loglikB,x_max,EXITFLAG_OPT] = ...
    %    getBundlesFromDBF(meas,protocol,dirB(1:nB,:),sig,SNR,x1,x3);
    
    
    
    
    
    
    
    
    
% di_ini=1.7e-9; % should it be 2.1451? 
% 
% [npeaks, dir_peaks, sc, predSig, logLik] = getPeaksFromDBF(meas,protocol,BasisDir,di_ini,sig);
% 
% BasisDirFocused = neighFromDirects(BasisDirHR,dir_peaks,12,npeaks);
% %dis=(1.5:0.25:2.0)*1e-9;
% dis = 1.7e-9;
% [npeaks2, dir_peaks2, sc2, predSig2, logLik2,~,~,~,di_max,~,alpha_iso] =  getPeaksFromDBF(meas,protocol,BasisDirFocused,dis,sig);
% if logLik2 > logLik
%     fprintf('\n mejor por %f', logLik2-logLik)
%     if npeaks2 < npeaks
%         fprintf('\n redujo un pico')    
%     end
% end
% 
% [nB, dirB, scB, szC_h_r ,cIso,szCIso,szCDot, predB_S, loglikB,x_max] =  getBundlesFromDBF(meas,protocol,BasisDirFocused,di_max,sig);

function vol = vector2volume(vec,idx,targetFile)

[~, xsize, ysize, zsize] = readNifti_andData(targetFile);


n = size(vec,2);
m = size(vec,3);


vec_tot = zeros(xsize*ysize*zsize,n,m);
nVoxels = size(vec,1);
for i=1:nVoxels
    % compute the index to 3D
    volume_index = (idx(i,3)-1)*ysize*xsize + (idx(i,2)-1)*xsize + idx(i,1);
    
    vec_tot(volume_index,:,:) = vec(i, :,:);
    
end
vol =  reshape(vec_tot, [xsize ysize zsize n m]);
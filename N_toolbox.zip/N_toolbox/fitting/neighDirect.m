function close_neigh = neighDirect(BasisDir,n)

    m = size(BasisDir,1);
    close_neigh = zeros(m,n);
    
    for i = 1:m
       dots = abs(BasisDir * BasisDir(i,:)');
       
       [vs idx] = sort(dots,1,'descend');
       
       close_neigh(i,:) = idx(1:n);
       
    end
    

end


function [fa, lc, pc, sc, md]= getFA(D)

    ls = getEigenVals(D);
    
    tr = sum(ls);
    md = tr/3;
    deno = norm(ls);
    fa = (sqrt(3)/sqrt(2)) *  norm(ls-md)/deno;
    
    % linear planar and spherical coeffs.
    
    if tr>0
        lc = (ls(1)-ls(2)) / tr;
        pc = 2*(ls(2)-ls(3)) / tr;
        sc = 3*ls(3)/ tr;
    else
        lc = 0;
        pc = 0;
        sc = 0;
    end
    
end





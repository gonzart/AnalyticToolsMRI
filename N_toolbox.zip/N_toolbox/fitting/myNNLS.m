function [x,resnorm,exit_flag] = myNNLS(A,b)

idx = 1:size(A,2);
i=0;
exit_flag =1;    

while true
    lA = A(:,idx);
    lx = (lA'*lA)\(lA'*b);
    
    
    if sum(lx<=0) == 0
        break;
    elseif i>20
        lx(lx<0) = 0;
        exit_flag = 0;
        break;
    end
    
    idx = idx(lx>0.00);
    i = i+1;    
end
resnorm = norm(lA*lx -b)^2;

x = zeros(size(A,2),1);
x(idx) = lx;
end
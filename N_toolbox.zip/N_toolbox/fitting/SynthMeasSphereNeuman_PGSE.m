function E=SynthMeasSphereNeuman_PGSE(x, grad_dirs, G, delta, smalldel, roots)
% Substrate: Impermeable spheres with one radius in an empty background.
% Orientation distribution: Watson's distribution with SH approximation
% Pulse sequence: Pulsed gradient spin echo
% Signal approximation: Gaussian phase distribution.
%
% [E,J]=SynthMeasSphereNeuman_PGSE(x, grad_dirs, G, delta, smalldel, roots)
% returns the measurements E according to the model 
%
% x is the list of model parameters in SI units:
% x(1) is the diffusivity of the material inside the cylinders.
% x(2) is the radius of the cylinders.
%
%
% G, delta and smalldel are the gradient strength, pulse separation and
% pulse length of each measurement in the protocol.  Each has
% size [N 1].
%
% roots contains solutions to the Bessel function equation from function
% BesselJ_RootsSphere.
%
% author: Alonso Ramirez from Gary Hui Zhang (gary.zhang@ucl.ac.uk)
% adapted to Spheres by: J Ramon Capetillo V (jose.capetillo@cimat.mx)

%just to sppeed up the computation
global VecLePars;
global VecLePerps;

if length(x) ~= 2
    error('the first argument should have exactly three parameters');
end

d=x(1);
R=x(2);

if ~isempty(VecLePerps)
    idxBoolFindPerp = VecLePerps(1,:) == d & VecLePerps(2,:) == R;
else
    idxBoolFindPerp = [];
end

if   sum ( idxBoolFindPerp ) == 0

    LePerp = SphereNeumanLePerp_PGSE(d, R, G, delta, smalldel, roots);
    
    VecLePerps = [VecLePerps , [d ; R; LePerp] ];

else
    LePerp = VecLePerps(3:end,idxBoolFindPerp);
end

g_squared = 1; % sqrt(sum(grad_dirs .^2,2))
gn_squeared = zeros(length(grad_dirs),1); %cosTheta.^2;

E = exp(LePerp .* (g_squared-gn_squeared)) ;


function [A,b] = fillMatrixVectorLSforNNLS(DBFs,meas)

    A = DBFs'* DBFs;
    b = DBFs'* meas;
    
%     N = size(DBFs,2);
%     A = zeros(N,N);
%     b = zeros(N,1);
%     for i=1:N
%         for j=i:N
%             A(i,j) = DBFs(:,i)'*DBFs(:,j);
%             A(j,i) = A(i,j);
%         end
%         b(i) = meas'* DBFs(:,i);
%     end
end
function [nB, dirB, scB] =  searchPeak(meas,protocol)

global actualFibreDir1 actualFibreDir2 NGT


dp = 1.7e-9;
dIso = 3.0e-9;


options = optimset('lsqnonneg');
optnew = optimset(options,'Display','off');

%Basis Dir
path_data = '/Users/alram/Dropbox/matlabs/data/NODDI_example_dataset/';
DBFDirectionsFileName = [path_data 'PuntosElectroN500.txt'];
BasisDir = load(DBFDirectionsFileName);
nTensoresBase = size(BasisDir,1);

% path_data = '/home/alram/matlabs/data/NODDI_example_dataset/';
% DBFDirectionsFileName = [path_data 'PuntosElectroN5000.txt'];
% BasisDirHR = load(DBFDirectionsFileName);

%Select Basis dir
BasisDirSmall = getPotentialDD_FromMeas(protocol,meas);

dots1 = abs(BasisDirSmall*actualFibreDir1);
[max1 idmax1] = max(dots1);
dots2 = abs(BasisDirSmall*actualFibreDir2);
[max2 idmax2] = max(dots2);


nB = 2;
dirB = [BasisDirSmall(idmax1,:);BasisDirSmall(idmax2,:)];
scB = [0.5 0.5];

return;

% idxs
bs = GetB_Values(protocol)';
idxB0 = (bs==0);
idxDW = (bs~=0);
%bsDW = bs(idxDW);

% compute whole DBF
[cosT_2_b,sinT_2_b] = createDataForDBF_stickAndBall(protocol,BasisDir);
DBFs = exp( dp*cosT_2_b + (dp/4)*sinT_2_b );


% get signal from iso compartment
Eiso = SynthMeasIsoGPD(dIso, protocol);
Eiso = Eiso(idxDW);
DBFs = [DBFs Eiso];

idxAnisotropic = 1:nTensoresBase;
idxIsotropic = nTensoresBase+1;
    
    
nAniso = size(idxAnisotropic,2);


%Signal preparation
S0r = mean(meas(idxB0));
Si = meas(idxDW);
Si = Si/S0r;


% whole data
[alphas, RESNORM_t,~,~] = lsqnonneg(DBFs,Si,optnew);
[nB_t, dirB_t, scB_t, ~, ~] = ...
            getDBF_NODDI_peaks_restricted(BasisDir,alphas(1:end-1),nAniso);
szCIso_t = alphas(idxIsotropic);
    


dirB = dirB_t;
scB = scB_t;


% BasisDirFocused = neighFromDirects(BasisDirHR,dirB_t,56,nB_t);
% [cosT_2_b_HR,sinT_2_b_HR] = createDataForDBF_stickAndBall(protocol,BasisDirFocused);
% DBFsHR = exp( dp*cosT_2_b_HR + (dp/10)*sinT_2_b_HR ); %% quiza cambiar (dp/4)
% DBFsHR = [DBFsHR Eiso];
% nTensoresBaseHR = size(BasisDirFocused,1);
% idxAnisotropicHR = 1:nTensoresBaseHR;
% idxIsotropicHR = nTensoresBaseHR+1;
% nAnisoHR = size(idxAnisotropicHR,2);


    NLEC = size(Si,1);
    outs = randperm(NLEC);
    nboostrap = NLEC;
    
    r= cell(nboostrap,1);
    
    v_nB = zeros(nboostrap+1,1);
    v_RESNORM = zeros(nboostrap+1,1);
    v_AngErr = zeros(nboostrap+1,1);
    
    v_nB(nboostrap+1) = nB_t;
    v_RESNORM(nboostrap+1) = RESNORM_t;
    [v_cost,v_nmas,v_nmenos] = PDDAssigment_and_NError(NGT,[actualFibreDir1';actualFibreDir2'],nB_t,dirB_t(1:nB_t,:));
    if v_nmas == 0 && v_nmenos == 0
        v_AngErr(nboostrap+1) = v_cost;
    else
        v_AngErr(nboostrap+1) = 90;
    end
    
    for n=1:nboostrap
        out = outs(mod(n-1,NLEC)+1);

        new_idx = setdiff(1:NLEC,out);
        
        [alphas, RESNORM,~,EXITFLAG_OPT] = lsqnonneg(DBFs(new_idx,:),Si(new_idx),optnew);
        [nB, dirB, scB, ~, ~] = getDBF_NODDI_peaks_restricted(BasisDir,alphas(1:end-1),nAniso);
        szCIso = alphas(idxIsotropic);
        
        r{n} = {nB, dirB, scB ,szCIso,RESNORM,EXITFLAG_OPT};
        v_nB(n) = nB;
        v_RESNORM(n) = RESNORM;
        
        [v_cost,v_nmas,v_nmenos] = PDDAssigment_and_NError(NGT,[actualFibreDir1';actualFibreDir2'],nB,dirB(1:nB,:));
        
        if v_nmas == 0 && v_nmenos == 0
            v_AngErr(n) = v_cost;
        else
            v_AngErr(n) = 45;
        end        
        
    end

    
    nB = median(v_nB);
%     
% %     figure; 
% %     hold on;
% % 
% %     plot3(1,0,0,'ko');    plot3(-1,0,0,'ko');    plot3(0,1,0,'ko');    
% %     plot3(0,-1,0,'ko');   plot3(0,0,1,'ko');    plot3(0,0,-1,'ko');
% %    
% %     
% %     plot3(actualFibreDir1(1),actualFibreDir1(2),actualFibreDir1(3),'bd');
% %     plot3(actualFibreDir2(1),actualFibreDir2(2),actualFibreDir2(3),'bd');
% %     
% %     for i=1:nB_t
% %         plot3(dirB_t(i,1),dirB_t(i,2),dirB_t(i,3),'gx');
% %     end
%     
%     
%     
%     maxIdx = -1;
%     maxRESNORM = 1e30;
%     
%     
%     count = 0;
%     dirData = zeros(sum(v_nB),3);
%     for n=1:nboostrap
% 
%         nB = r{n}{1};
%         dirB = r{n}{2};
%         scB = r{n}{3};
%         szCIso = r{n}{4};
%         RESNORM = r{n}{5};
%         out = outs(mod(n-1,NLEC)+1);
%         
%         if RESNORM < maxRESNORM %&& nB == 2 
%             maxRESNORM = RESNORM;
%             maxIdx = n;
%             max_nB = nB;
%             max_dirB = dirB;
%         end
%         
%         
%         %fprintf('\n b(out) = %d - nB = %d szCIso = %f ',bsDW(out), nB,szCIso);
%         
%         for i=1:nB
%             %fprintf(' szB %d = %f',i,scB(i));
%             %plot3(dirB(i,1),dirB(i,2),dirB(i,3),'r+');
%             
%             count = count + 1; 
%             dirData(count,1:3) = dirB(i,:);
%         end
%         
%     end
% 
%     
%     %fprintf('\n\n All data ***   nB_t %f, szCIso_t %f RESNORM_t %f \n',nB_t,szCIso_t, RESNORM_t);
%     %display(scB_t)
%     
%     %fprintf('\n\n BEST ***   max_nB %f, maxRESNORM %f \n',max_nB,maxRESNORM );
% 
%     %for i=1:max_nB
%         %plot3(max_dirB(i,1),max_dirB(i,2),max_dirB(i,3),'k+');
%     %end
%     
%     scB = r{maxIdx}{3};
%     szCIso = r{maxIdx}{4};
%     RESNORM = r{maxIdx}{5};
%     out = outs(mod(maxIdx-1,NLEC)+1);
%     
%     %fprintf('\n  b(out) = %d -   szCIso = %f RESNORM = %f',bsDW(out),szCIso,RESNORM);
%     %display(scB)
% 
%     for i=1:nB_t
%         count = count + 1; 
%         dirData(count,1:3) = dirB_t(i,:);    
%     end
%     
%     %fprintf('\n\n Result of bagging *** \n\n *********   nB %f \n',median(v_nB));
%     
%     max_nB = max(v_nB);
%     
%     [~, centroids ] = kmeans(dirData, max_nB);
%     
%     
%     %for i=1:max_nB
%         %plot3(centroids(i,1),centroids(i,2),centroids(i,3),'om');
%     %end
%     dirB = centroids;
%     hold off;
%     
end

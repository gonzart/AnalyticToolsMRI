function [x ,nIteraUsed]= SOR_GS(A,b,xini, w,nItera,eps)

    N = size(A,1);
    x = xini; 
    xold = x;
    
    
    for nIteraUsed=1:nItera
        
        for i= 1:N

            news = 0;
            for j=1:i-1
                news = news + A(i,j)*x(j);
            end
            
            olds = 0;
            for j=i+1:N
                olds = olds + A(i,j)*xold(j);
            end
            
            x(i) = (1-w)*xold(i) + w/A(i,i)* (b(i) - news - olds ) ;
            if x(i)<0
                x(i) = 0;
            end
        end
        if norm(xold - x)/norm(xold) < eps
            break
        end
        xold = x;
    end
    
end
function [T , stickSC , TSC, ballSC, irFrac] = x2Params_sticks_ball(x)

    ballSC = x(1);
    stickSC = (1-x(1))*x(2);
    TSC = (1-x(1))*(1-x(2));
    irFrac = x(3);
    d = x(4:9);
    T = [d(1) d(4) d(5); d(4) d(2) d(6); d(5) d(6) d(3)];
    

end
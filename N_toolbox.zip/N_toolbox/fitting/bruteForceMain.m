function [xsc_max, ricLogLik_max, SPred_max] = bruteForceMain(model,meas,protocol,xsc0,nWorkers,sig)


    [xs ,idxSplit,idxs_workers] = setupBruteForce(model,xsc0,nWorkers);

    

    clus = parcluster();
    
    fprintf('\n\n Lanzando en paralelo \n\n')

    
    %for i=1:nWorkers        
    %    [a, b, c] = batch_SynthMeas_2stick_1ball_1dot(xs,i,idxSplit,idxs_workers,protocol,meas,sig);
    %end
    
    
    for i=1:nWorkers        
        hand(i) = batch(clus,@batch_SynthMeas_2stick_1ball_1dot,3,{xs,i,idxSplit,idxs_workers,protocol,meas,sig});
    end
    fprintf('\n\n esperando \n\n')
    
    for i=1:nWorkers        
        wait(hand(i));
    end

    
    fprintf('\n\n recuperando info \n\n')
    
    
    lik_max_s =[];
    x_max_s = [];
    SPred_max_s = [];
    
    for i=1:nWorkers
         rs=fetchOutputs(hand(i));
        lik_max_s(i) = rs{1};
         x_max_s(i,:) = rs{2};
         SPred_max_s(i,:) = rs{3};
    end
    
    
    for i=1:nWorkers
        delete(hand(i));
    end
    
    [ricLogLik_max,idx_max] = max(lik_max_s);
    xsc_max = x_max_s(idx_max,:)';
    SPred_max = SPred_max_s(idx_max,:)';
    
end

function [lik_max, x_max,SPred] = batch_SynthMeas_2stick_1ball_1dot(xs,id,idxSplit,idxs_workers,protocol,meas,sig)

    grid = combvec(xs(1,:),xs(2,:),xs(3,:),xs(4,:),xs(5,:),xs(6,:),xs(7,:),xs(8,:),xs(9,:),xs(10,:),xs(11,idxs_workers(id)+1:idxs_workers(id+1) ));
    %grid = combvec(xs(1,1:2),xs(2,1:2),xs(3,:),xs(4,:),xs(5,:),xs(6,:),xs(7,:),xs(8,:),xs(9,:),xs(10,:),xs(11,idxs_workers(id)+1:idxs_workers(id+1) ));
    
    fprintf('\n 1 Aqui %d\n', id)
    n= size(grid,2);
    
    lik_max = -1e30;
    %for j=1:n
    for j=1:10
        S = SynthMeas_2stick_1ball_1dot(meas, grid(:,j),protocol);
        lik = RicianLogLik(meas, S, sig);
        if lik_max < lik
            lik_max = lik;
            x_max = grid(:,j);
            SPred = S;
        end
    end
    
    fprintf('\n 1 alla %d\n', id)
    
    %SPred
    

end


function [xs ,idxSplit,idxs_workers] = setupBruteForce(model,x0,nWorkers)

    if strcmp(model, 'SynthMeas_2stick_1ball_1dot') == true
        
        n_inc = 5;
        [xs ,idxSplit,idxs_workers] = setupBruteForce_SynthMeas_2stick_1ball_1dot(x0,n_inc,nWorkers);
        
    end

end


function [xs ,idxSplit,idxs_workers]= setupBruteForce_SynthMeas_2stick_1ball_1dot(x0,n_inc,nWorkers)

    % model   Si = a_1 exp(-b stick(di_1,tetha_1,phi_1))
    %            + a_2 exp(-b stick(di_2,tetha_2,phi_2))
    %            + a_3 exp(-b diso) + a_4

    % xsc = [a1 a_2 a_3 a_4 di_1 di_2 theta_1 theta_2 phi_1 phi_2 diso]

    idx = 1; %a_1 stick 1
    if x0(idx) == 0
        x_ini = 0.0; 
        x_fin = 0.5;
    else
        x_ini = x0(idx)/2.0; 
        x_fin = x0(idx) + x0(idx)/2.0;
    end
    xs(idx,:) = (x_ini:(x_fin-x_ini)/(n_inc-1):x_fin);        
    
    
    
    
    idx = 2; %a_2 stick 2
    if x0(idx) == 0
        x_ini = 0.0; 
        x_fin = 0.5;
    else
        x_ini = x0(idx)/2.0; 
        x_fin = x0(idx) + x0(idx)/2.0;
    end
    xs(idx,:) = (x_ini:(x_fin-x_ini)/(n_inc-1):x_fin);        
    
    
    
    
    idx = 3; %a_3 ball
    if x0(idx) == 0
        x_ini = 0.0; 
        x_fin = 0.5;
    else
        x_ini = x0(idx)/2.0; 
        x_fin = x0(idx) + x0(idx)/2.0;
    end
    xs(idx,:) = (x_ini:(x_fin-x_ini)/(n_inc-1):x_fin);        

    
    
    idx = 4; %a_4 dot
    if x0(idx) == 0
        x_ini = 0.0; 
        x_fin = 0.1;
    else
        x_ini = x0(idx)/2.0; 
        x_fin = x0(idx) + x0(idx)/2.0;
    end
    xs(idx,:) = (x_ini:(x_fin-x_ini)/(n_inc-1):x_fin);        
    
    
    idx = 5; %di_1
    if x0(idx) == 0
        x_ini = 1e-9; 
        x_fin = 3e-9;
    else
        x_ini = x0(idx) - 0.5e-9; 
        x_fin = x0(idx) + 0.5e-9;
    end
    xs(idx,:) = (x_ini:(x_fin-x_ini)/(n_inc-1):x_fin);        
    
    
    idx = 6; %di_2
    if x0(idx) == 0
        x_ini = 1e-9; 
        x_fin = 3e-9;
    else
        x_ini = x0(idx) - 0.5e-9; 
        x_fin = x0(idx) + 0.5e-9;
    end
    xs(idx,:) = (x_ini:(x_fin-x_ini)/(n_inc-1):x_fin);        
    
    
    idx = 7; % theta_1
    if x0(idx) == 0
        x_ini = 0; 
        x_fin = pi/2;
    else
        x_ini = x0(idx) - 20*pi/180; 
        x_fin = x0(idx) + 20*pi/180;
    end
    xs(idx,:) = (x_ini:(x_fin-x_ini)/(n_inc-1):x_fin);        

    idx = 8;% theta_2
    if x0(idx) == 0
        x_ini = 0; 
        x_fin = pi/2;
    else
        x_ini = x0(idx) - 20*pi/180; 
        x_fin = x0(idx) + 20*pi/180;
    end
    xs(idx,:) = (x_ini:(x_fin-x_ini)/(n_inc-1):x_fin);        
    
    
    idx = 9; %phi_1
    if x0(idx) == 0
        x_ini = 0; 
        x_fin = pi;
    else
        x_ini = x0(idx) - 20*pi/180; 
        x_fin = x0(idx) + 20*pi/180;
    end
    xs(idx,:) = (x_ini:(x_fin-x_ini)/(n_inc-1):x_fin);        
    
    
    idx = 10; %phi_2
    if x0(idx) == 0
        x_ini = 0; 
        x_fin = pi;
    else
        x_ini = x0(idx) - 20*pi/180; 
        x_fin = x0(idx) + 20*pi/180;
    end
    xs(idx,:) = (x_ini:(x_fin-x_ini)/(n_inc-1):x_fin);        

    
    idx = 11; %diso
    % n_inc of last one must be a multiply of nWorkers
    n= double(int32(n_inc/nWorkers));
    n_inc_w = n*nWorkers;
    if x0(idx) == 0
        x_ini = 0.5e-9; 
        x_fin = 3.0e-9;
    else
        x_ini = x0(idx) - 1e-9; 
        x_fin = x0(idx) + 1e-9;
    end
    xs(idx,1:n_inc_w) = (x_ini:(x_fin-x_ini)/(n_inc_w-1):x_fin);        
    
    idxSplit = 11;
    idxs_workers = [0 n_inc_w/nWorkers:n_inc_w/nWorkers:n_inc_w];
    
end
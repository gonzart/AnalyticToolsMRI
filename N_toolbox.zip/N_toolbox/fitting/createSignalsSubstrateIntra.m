function [S_tot,Ss_individual,compartmentSizes] = createSignalsSubstrateIntra(rads,coeff_diff,N_cyl,protocol,orientation)

    global VecLePars;
    global VecLePerps;

    VecLePars = [];
    VecLePerps = [];
    
    starts = 40; % for large diameters
    roots = BesselJ_RootsCyl(starts);
    for i=1:N_cyl
        intra_x = [coeff_diff;rads(i)];
        Ss_individual(:,i) = SynthMeasCylNeuman_PGSE(intra_x, protocol.grad_dirs, protocol.G', protocol.delta', protocol.smalldel', orientation, roots);
    end
    compartmentSizes = pi*rads.^2;
    compartmentSizes = compartmentSizes ./ sum(compartmentSizes);
    
    %figure; plot(rads,compartmentSizes);
    
    S_tot = Ss_individual * diag(compartmentSizes);
    S_tot = sum( S_tot, 2);
end
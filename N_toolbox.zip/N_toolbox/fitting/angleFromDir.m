function [theta,phi] = angleFromDir(dir)

    theta = acos(  dir(3)   );
    phi = atan2( dir(2) ,  dir(1) );

function [np, contri_r, w_r, alphas_peaks, idx_Peaks] = getDBF_NODDI_peaks_restricted(BasisDir,alphas_r,nTensoresBase)

th = 0.2; % 0.25 before

contri_r = zeros(3,3);


alphas_peaks = zeros(size(alphas_r));

%restricted
%alphas_r = alphas(nTensoresBase+1:2*nTensoresBase);

%hindered
%alphas_r = alphas(1:nTensoresBase);

[valMax, idxMax]  = max(alphas_r);

if valMax < 0.025
    np = 0;
    contri_r = [];
    w_r = [];
    idx_Peaks = [];
    return
end
np = 1;

contri_r(np,:) = BasisDir(idxMax,:) ;

alphas_peaks(idxMax) = alphas_r(idxMax);

w_r = alphas_r(idxMax);

idx_Peaks(np) = idxMax;

%alphas_r(idxMax) = 0;
% turn off everything 20 degrees around

for k=1:nTensoresBase
    if acos(abs(BasisDir(idxMax,:)*BasisDir(k,:)'))  < 20*pi/180  
        %alphas_peaks(k) = alphas_r(k);
        alphas_r(k) = 0;
    end
end


[valMax2, idxMax2]  = max(alphas_r);

if valMax2 > valMax * th  % if is not noise
    np = np + 1;
    contri_r(2,:) = BasisDir(idxMax2,:) ;
    alphas_peaks(idxMax2) = alphas_r(idxMax2);
    w_r(np) = alphas_r(idxMax2);
    idx_Peaks(np) = idxMax2;

    
    for k=1:nTensoresBase
        if acos(abs(BasisDir(idxMax2,:)*BasisDir(k,:)'))  < 20*pi/180  
            %alphas_peaks(k) = alphas_r(k);
            alphas_r(k) = 0;
        end
    end
    
else
    return
end


[valMax3, idxMax3]  = max(alphas_r);

if valMax3 > valMax * th  % if is not noise
    np = np + 1;
    contri_r(np,:) = BasisDir(idxMax3,:);
    alphas_peaks(idxMax3) = alphas_r(idxMax3);
    w_r(np) = alphas_r(idxMax3);
    idx_Peaks(np) = idxMax3;

    
%    for k=1:nTensoresBase
%        if acos(abs(BasisDir(idxMax3,:)*BasisDir(k,:)'))  < 20*pi/180  
            %alphas_r(k) = 0;
            %alphas_peaks(k) = alphas_r(k);
%        end
%    end
    
end


end
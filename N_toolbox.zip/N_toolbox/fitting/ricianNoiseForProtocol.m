function [SNoisy, sigma] = ricianNoiseForProtocol(S, SNR,protocol)


bs = GetB_Values(protocol)';
idxB0 = (bs==0);


meanB0 = mean(S(idxB0));

sigma = meanB0 / SNR;

SNoisy = sqrt(  (S+randn(size(S))*sigma).^2 + (randn(size(S))*sigma).^2 );
function [anisDBF vecsDisp idxBoundles]= anisotropicDBFFromDirs(Dirs,np,di,dr1,dr2,protocol,oldDBFs ,idx_Peaks,nRotations)
    bs = GetB_Values(protocol)';
    idxDW = (bs~=0);
    bs = bs(idxDW);

    %nRotations = 72;
    angle = pi/nRotations;
    
    
    anisDBF = [];
    vecsDisp = [];
    
    for i=1:np
            
            [dbf vecdisp] = rotationalBasis(Dirs(i,:)',nRotations,angle,protocol,di,dr1,dr2,bs,idxDW);
            
            anisDBF = [anisDBF dbf];
            vecsDisp = [vecsDisp;vecdisp];
            idxBoundles(i,:) = [ (1:size(dbf,2))+(i-1)*size(dbf,2) np*size(dbf,2)+i];

    end
    
    for i=1:np        
        anisDBF = [anisDBF oldDBFs(:,idx_Peaks(i))];
    end    
    
    % get signal from iso compartment
    dIso = 1e-9;
    Eiso = SynthMeasIsoGPD(dIso, protocol);
    anisDBF = [ anisDBF Eiso(idxDW)];
    
    


end
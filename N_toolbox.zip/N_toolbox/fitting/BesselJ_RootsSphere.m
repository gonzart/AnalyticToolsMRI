function root = BesselJ_RootsSphere(starts)
% BesselJ_RootsSphere(starts) finds the roots of the equation x*J'_3/2(x)-1/2J3/2(x) = 0
% where J_3/2 is the 3/2 order Bessel function of the first kind.
%
% starts is the number of starting points in the search for
% roots.  The larger it is, the more roots are returned in the root array.
% The default is 100, which returns 32 roots. 
% Generally the number of roots is just under 1/3 the number of starting
% points.
%
% author: Daniel C Alexander (d.alexander@ucl.ac.uk)
% adapted to Spheres by: J Ramon Capetillo V (jose.capetillo@cimat.mx)
if(nargin==0)
    starts = 100;
end

J_1_5 = @(x)(0.5*(besselj((1/2),x) - besselj((5/2),x)));
% Get a good list of starting points
be_1_5=@(x)besselj((3/2),x);
f= @(x)(((x).* J_1_5(x))-(1/2).*be_1_5(x)) ;%Ec.(19)

y = 0:0.1:starts;


dJ1_5=f(y);
dj1_5 = J_1_5(y);
Be_1_5=be_1_5(y);


starts = (find(dJ1_5(1:end-1).*dJ1_5(2:end)<0)+1)*0.1;

for s=1:length(starts)
    root(s) = fzero(f,starts(s));

end

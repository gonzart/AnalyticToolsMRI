function [protocol_train,meas_train, protocol_test, meas_test] = split_train_test_Protocol(meas,protocol, bval,bvec,G,delta,DELTA,TE, percentTest)

nDW =  protocol.totalmeas-protocol.numZeros;
ntest =  round( nDW * (percentTest/100) );
ntrain = nDW - ntest;


while true
    
    idxBooltest = [ones(ntest,1) ; zeros(ntrain,1)];
    idxBooltest = logical(idxBooltest(randperm(nDW)));
    
    idxtest = protocol.dw_Indices(idxBooltest);
    idxtrain = protocol.dw_Indices(~idxBooltest);
    
    TEs_test = unique(TE(idxtest));
    TEs_train = unique(TE(idxtrain));
    
    %ensure all the shells are included in both protocols    
    %if length(TEs_test) < length(protocol.uTE) || length(TEs_train) < length(protocol.uTE)
    if length(TEs_train) < length(protocol.uTE) % (change: only in train)
        continue;
    end
    
    
    idxWithTE = [];
    for i=1:length(TEs_test)
        idxWithTE = [idxWithTE ; find( TE == TEs_test(i) ) ];
    end
    idxB0WithTE = intersect( idxWithTE , protocol.b0_Indices );
    
    idxFinal_test = [ idxB0WithTE ; idxtest];
    meas_test = meas(idxFinal_test);
    protocol_test = Challenge2015_2_Protocol(bval(idxFinal_test), bvec(idxFinal_test,:),G(idxFinal_test),delta(idxFinal_test),DELTA(idxFinal_test),TE(idxFinal_test));
    
    
    
    idxWithTE = [];
    for i=1:length(TEs_train)
        idxWithTE = [idxWithTE ; find( TE == TEs_train(i) ) ];
    end
    
    idxB0WithTE = intersect( idxWithTE , protocol.b0_Indices );
    
    idxFinal_train = [ idxB0WithTE ; idxtrain];
    
    meas_train = meas(idxFinal_train);
    protocol_train = Challenge2015_2_Protocol(bval(idxFinal_train), bvec(idxFinal_train,:),G(idxFinal_train),delta(idxFinal_train),DELTA(idxFinal_train),TE(idxFinal_train));
    
    %ensure all the shells are included in both protocols (change: only in train)
    if protocol_train.M == protocol.M  % && protocol_test.M == protocol.M
        break;
    end
    
    
end

end
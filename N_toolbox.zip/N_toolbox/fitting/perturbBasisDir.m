function BasisDir = perturbBasisDir(BasisDir,maxAngle)


    n= size(BasisDir,1);
    anglesP = pi/2 + (round(rand(n,1))*2-1).*rand(n,1)*maxAngle*pi/180;
    anglesA = (round(rand(n,1))*2-1).*rand(n,1)*maxAngle*pi/180;
    
    for i = 1:n
        
        v = [ sin(anglesP(i))*cos(anglesA(i)) ; sin(anglesP(i))*sin(anglesA(i)) ; cos(anglesP(i))];
        mtx = fromToRotation([1 ;0 ;0], v);
        BasisDir(i,:) = (mtx*BasisDir(i,:)')';
    end
        
        

end
function [x, fval, SPredStickBall ] = fitTensorToSticks_Grid(SSticks,SBall, protocol,meas,sig)
    
    %lb = [0.0 0.0   0.0506-0.01    -20e-9 -20e-9 -20e-9 -20e-9 -20e-9 -20e-9 ];
    %ub = [0.1  1    0.0506+0.01     20e-9  20e-9  20e-9  20e-9  20e-9  20e-9 ];

    n_inc = 2;
    x1_ini = 0.0; 
    x1_fin = 0.1;
    x1_vs = (x1_ini:(x1_fin-x1_ini)/(n_inc-1):x1_fin);

    
    n_inc = 3;
    x2_ini = 0.0; 
    x2_fin = 1.0;
    x2_vs = (x2_ini:(x2_fin-x2_ini)/(n_inc-1):x2_fin);
    
    n_inc = 3;
    x3_ini = 0.0506-0.05; 
    x3_fin = 0.0506+0.05;
    x3_vs = (x3_ini:(x3_fin-x3_ini)/(n_inc-1):x3_fin);
    
    n_inc = 4;
    x4_ini = -5e-9; 
    x4_fin =  5e-9;
    x4_vs = (x4_ini:(x4_fin-x4_ini)/(n_inc-1):x4_fin);
    
    x5_vs = x4_vs;
    x6_vs = x4_vs;
    x7_vs = x4_vs;
    x8_vs = x4_vs;
    x9_vs = x4_vs;

    
    grid = combvec(x1_vs,x2_vs,x3_vs,x4_vs,x5_vs,x6_vs,x7_vs,x8_vs,x9_vs);
    n= size(grid,2);
    
    liks= zeros(n,1);
    for j=1:n
        SStickTensorB0Ball = SynthMeasSticks(grid(:,j),protocol,SSticks,SBall);
        liks(j) = RicianLogLik(meas, SStickTensorB0Ball, sig);
    end
    
    [v ind] = max(liks);
    x = grid(:,ind);
    
    fval = v;
    
    SPredStickBall = SynthMeasSticks(x,protocol,SSticks,SBall);

end
function [b0 , S_NODDI , recoveredFibreDir , loglikNODDI , sig , xsc] = getFitedDataNoddi(meas,model,protocol,ml)


recoveredFibreDir = GetFibreOrientation(model.name, ml);
b0 = GetB0(model.name, ml);

% recover NODDI signal
scale = GetScalingFactors(model.name);
xsc = ml(1:(length(scale)-1))./scale(1:(end-1));
S_NODDI = SynthMeas(model.name, xsc, protocol, recoveredFibreDir, 0);

% compute logLik NODDI
sig = EstimateSigma(meas, protocol, model);
loglikNODDI = RicianLogLik(meas, S_NODDI, sig);

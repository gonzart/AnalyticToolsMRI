function [Sh, Sr, Siso, Stot] = signalNODDI_hind_restr(x,protocol,fibreDir)

% % generates separated signals for hindered an restricted from vector x as
% x(1) = 0.5; %is the volume fraction of the intracellular space.
% x(2) = 1.7e-9; %is the free diffusivity of the material inside and outside the cylinders.
% x(3) = 4; %is the concentration parameter of the Watson's distribution.
% x(4) = 0.2; %is the volume fraction of the isotropic compartment.
% x(5) = 3e-9; %is the diffusivity of the isotropic compartment.
% x(6) = S0; %is the measurement at b=0.


% get signal from iso compartment
dIso = x(5);
Siso = SynthMeasIsoGPD(dIso, protocol);

% build the input x vector for hindered compartment
f = x(1);
dPar = x(2);
dPerp = dPar*(1-f);
kappa = x(3);
x_h = [dPar dPerp kappa];
Sh = SynthMeasWatsonHinderedDiffusion_PGSE(x_h, protocol.grad_dirs, protocol.G', protocol.delta', protocol.smalldel', fibreDir);

% build the input x vector for restricted compartment
R = 0;
roots = 0;
x_r = [dPar R kappa];
Sr = SynthMeasWatsonSHCylNeuman_PGSE(x_r, protocol.grad_dirs, protocol.G', protocol.delta', protocol.smalldel', fibreDir, roots);

% get the whole signal
s0r = x(6);
fiso = x(4);
Eaniso=(1-f)*Sh + f*Sr;
Stot = s0r * ( (1-fiso)*Eaniso + fiso*Siso );

end
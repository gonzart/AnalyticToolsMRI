function n = sizeDBFComplete_DifTE(protocol,fibreDir)

bs = GetB_Values(protocol)';
idxDW = (bs~=0);

[~,nDir,~,nCom_intra,~,nComExtra,~,nIsoComp,~] = setParamsDBFChallenge2015(protocol,idxDW,fibreDir);

n = (nCom_intra+nComExtra)*nDir+nIsoComp+1;

end
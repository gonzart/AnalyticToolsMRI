function [DBFs , idxAnisotropic, idxIsotropic,dIsoCoeff] = createDBF_NODDI_WatsonSHStickTortIsoV_B0( BasisDir, lecDir, protocol,x)
%createDBF      Compute the DBFs matrix for the DBF model.
%
%   DBFs = createDBF_NODDI( x, BasisDir, lecDir , nTensoresBase, NLEC, bs)
%   Compute the the DBFS (for different b values) matrix given the basis-tensor's longitudinal and transversal 
%   diffusion DPDD and DTRA for the set of orientations BASISDIR and for the set of
%   diffusion encoding orientation (MRI machine gradient directions) LECDIR and b-value
%   B, as is explained in:
%   A. Ramirez-Manzanares etal, Diffusion Basis Functions Decomposition for Estimating 
%   White Matter Intravoxel Fiber Geometry. IEEE Trans. Med. Imaging 26(8): 2007.
%
%   Alonso Ramirez.  
%   $Date: 2008/10/21$



bs = GetB_Values(protocol)';
idxDW = (bs~=0);

nTensoresBase = size(BasisDir,1);
NLEC = size(lecDir,1);

%DBFs = zeros(NLEC,2*nTensoresBase); % N hindered + N restricted
DBFs = zeros(NLEC,nTensoresBase); % N (hindered and restricted)



for j=1:nTensoresBase
    
    fibreDir = BasisDir(j,:)';
        
    [Sh, Sr] = signalNODDI_hind_restr(x,protocol,fibreDir);
    
    DBFs(:,j) = x(1)*Sr(idxDW) + (1-x(1))*Sh(idxDW);
    
    %DBFs(:,j              ) = Sh(idxDW);
    %DBFs(:,j+nTensoresBase) = Sr(idxDW);
end

% % get signal from iso compartment
% dIso = 1e-9;
% Eiso = SynthMeasIsoGPD(dIso, protocol);
% DBFs(:,2*nTensoresBase+1) = Eiso(idxDW);
% dIso = 1.5e-9;
% Eiso = SynthMeasIsoGPD(dIso, protocol);
% DBFs(:,2*nTensoresBase+2) = Eiso(idxDW);
% dIso = 2e-9;
% Eiso = SynthMeasIsoGPD(dIso, protocol);
% DBFs(:,2*nTensoresBase+3) = Eiso(idxDW);
% dIso = 2.5e-9;
% Eiso = SynthMeasIsoGPD(dIso, protocol);
% DBFs(:,2*nTensoresBase+4) = Eiso(idxDW);
% dIso = 3e-9;
% Eiso = SynthMeasIsoGPD(dIso, protocol);
% DBFs(:,2*nTensoresBase+5) = Eiso(idxDW);
% dIso = 3.5e-9;
% Eiso = SynthMeasIsoGPD(dIso, protocol);
% DBFs(:,2*nTensoresBase+6) = Eiso(idxDW);
% DBFs(:,2*nTensoresBase+7) = ones(NLEC,1); %dot
% 
% idxAnisotropic = 1:2*nTensoresBase;
% idxIsotropic = 2*nTensoresBase+1:2*nTensoresBase+7;
% 
% dIsoCoeff = 1e-9:0.5e-9:3.5e-9;


% % get signal from iso compartment
% dIso = 3e-9;
% Eiso = SynthMeasIsoGPD(dIso, protocol);
% DBFs(:,2*nTensoresBase+1) = Eiso(idxDW);
% DBFs(:,2*nTensoresBase+2) = ones(NLEC,1); %dot
% 
% idxAnisotropic = 1:2*nTensoresBase;
% idxIsotropic = 2*nTensoresBase+1:2*nTensoresBase+2;
% 
% dIsoCoeff = 3.0e-9;

% get signal from iso compartment
dIso = x(5);
Eiso = SynthMeasIsoGPD(dIso, protocol);
DBFs(:,nTensoresBase+1) = Eiso(idxDW);
%DBFs(:,nTensoresBase+2) = ones(NLEC,1); %dot

idxAnisotropic = 1:nTensoresBase;
idxIsotropic = nTensoresBase+1; %:nTensoresBase+2;

dIsoCoeff = dIso;




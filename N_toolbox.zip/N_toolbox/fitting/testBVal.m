function testBVal

    clc
    clear
    close all

    G= 0.280;
    DELTA= 0.033;
    delta= 0.0015;
    TE = DELTA+2*delta;
    
    bval = bvalFromOthers(G,DELTA,delta) 

    d_true = 0.45e-9; 
    
    % the best
    %s_0 = 500e3; 
    %s   = 416555;
    % err = 0.011009515244989
    
    % the best
    s_0 = 94e3; 
    s   = 78257.6;
    
    
    d_est = -log(s/s_0)/bval
    
    err = abs(d_true - d_est)/d_true
    

    %d_tortousity = (1-0.5675)*d_true
    
    %T=5e3;
    %l_step = sqrt(6*d_true*TE/T)
    
%     incre = pi/16;
%     for angle=0:incre:2*pi-incre 
%         fprintf('\n%.4f %.4f 0 %.4f %.4f %.4f %.4f ', cos(angle), sin(angle), G, DELTA,delta,DELTA+2*delta)
%     end

end

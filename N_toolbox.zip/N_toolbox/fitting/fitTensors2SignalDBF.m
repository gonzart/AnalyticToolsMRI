function [scFib, Ds, TotalSignal,disper] = fitTensors2SignalDBF(np,alphas_a,anisDBF,meas, protocol,idxBoundles,pdds,idxIso)


    bs = GetB_Values(protocol)';
    idxB0 = (bs==0);
    idxDW = (bs~=0);
    

    S0r = mean(meas(idxB0));


    scFib = zeros(1,3);
    Ds= zeros(3,7);
    disper= zeros(3,3);
    
    TotalSignal = meas;
    TotalSignal(idxDW) = zeros(sum(idxDW),1);
    for i=1:np
        scFib(i) = sum(alphas_a(idxBoundles(i,:)));
        
        SBundle = meas*scFib(i); % S0 is also multiplied
        SBundle(idxDW) = S0r*anisDBF(:,idxBoundles(i,:)) * alphas_a(idxBoundles(i,:));
        
        
        [D STensor] = FitLinearDT(SBundle, protocol);
        T = MakeDT_Matrix(D(2), D(3), D(4), D(5), D(6), D(7));
        TotalSignal(idxDW) = TotalSignal(idxDW) + STensor(idxDW); % * scFib(i);        
        Ds(i,:) = D;
        
        [v, d] = eig(T);
        [~ ,idxs] = sort(diag(d));
        
        disper(i,:) = v(:,idxs(2));
        
        Ds(i,1+1) = D(1+1);
        Ds(i,2+1) = D(2+1);
        Ds(i,3+1) = D(4+1);
        Ds(i,4+1) = D(5+1);
        Ds(i,5+1) = D(6+1);
        Ds(i,6+1) = D(3+1);
        

        seeSignalQlty(SBundle,STensor,protocol,pdds(i,:)',S0r); title 'S Tensor individual'

        
%         myTheta = acos(  pdds_2(posy,posx,posz,i,3)   );
%         myPhi = atan2( pdds_2(posy,posx,posz,i,2) ,  pdds_2(posy,posx,posz,i,1) );
%         
%         %noddi_b.GS.fixedvals(GetParameterIndex(noddi_b.name, 'di')) = di_max; % di is fixed to each particular value
%         %noddi_b.GD.fixedvals(GetParameterIndex(noddi_b.name, 'di')) = di_max;        
%         noddi_b.GS.fixedvals(GetParameterIndex(noddi_b.name, 'theta')) = myTheta; % angle is fixed to each particular value
%         noddi_b.GD.fixedvals(GetParameterIndex(noddi_b.name, 'theta')) = myTheta;
%         noddi_b.GS.fixedvals(GetParameterIndex(noddi_b.name, 'phi')) = myPhi; % angle is fixed to each particular value
%         noddi_b.GD.fixedvals(GetParameterIndex(noddi_b.name, 'phi')) = myPhi;
%         
%         [gs_b fgs_b ml_b] = ThreeStageFittingVoxel(SBundle, protocol, noddi_b, 0);
%         scale_b = GetScalingFactors(noddi_b.name);
%         xsc_b = ml_b(1:(length(scale_b)-1))./scale_b(1:(end-1));
%         recoveredFibreDir_b = GetFibreOrientation(noddi_b.name, ml_b);
% 
%         S_NODDI_b = SynthMeas(noddi_b.name, xsc_b, protocol, recoveredFibreDir_b, 0); %  * scFib(i);
%         TotalSignal(idxDW) = TotalSignal(idxDW) + S_NODDI_b(idxDW);      
%         seeSignalQlty(SBundle,S_NODDI_b,protocol,recoveredFibreDir_b,b0); title 'S S-NODDI-bundle'
        
    end

    % add the isotropic part
    
    TotalSignal(idxDW) = TotalSignal(idxDW) + anisDBF(:,idxIso)*alphas_a(idxIso);


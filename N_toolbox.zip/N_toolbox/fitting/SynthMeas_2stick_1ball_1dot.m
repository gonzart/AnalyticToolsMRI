function SSynth = SynthMeas_2stick_1ball_1dot(meas,xsc,protocol)
    % model   Si = a_1 exp(-b stick(di_1,tetha_1,phi_1))
    %            + a_2 exp(-b stick(di_2,tetha_2,phi_2))
    %            + a_3 exp(-b diso) + a_4

    % xsc = [a1 a_2 a_3 a_4 di_1 di_2 theta_1 theta_2 phi_1 phi_2 diso]
    
    a_1 = xsc(1);
    a_2 = xsc(2);
    a_3 = xsc(3);
    a_4 = xsc(4);
    di_1 = xsc(5);
    di_2 = xsc(6);
    theta_1 = xsc(7);
    theta_2 = xsc(8);
    phi_1 = xsc(9);
    phi_2 = xsc(10);
    diso = xsc(11);
    
    bs = GetB_Values(protocol)';
    idxB0 = (bs==0);
    idxDW = (bs~=0);

    b0 = mean(meas(idxB0));
    bs = bs(idxDW);
    lecDir = protocol.grad_dirs(idxDW,:);
    
    NLEC = size(bs,1);
    S = zeros(NLEC,1);
    for i=1:NLEC
        fibredir1 = [cos(phi_1).*sin(theta_1) sin(phi_1).*sin(theta_1) cos(theta_1)]';
        fibredir2 = [cos(phi_2).*sin(theta_2) sin(phi_2).*sin(theta_2) cos(theta_2)]';
        
        S(i) =  a_1 * exp(-bs(i) * di_1 * (lecDir(i,:)*fibredir1)^2 ) ...
             +  a_2 * exp(-bs(i) * di_2 * (lecDir(i,:)*fibredir2)^2 ) ...            
             +  a_3 * exp(-bs(i) * diso) + a_4 ;           
    end
    
    
    SSynth = meas;
    SSynth(idxDW) = b0*S;
    
end

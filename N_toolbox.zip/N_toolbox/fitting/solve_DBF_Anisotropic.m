function [pred_DBF_S_a loglikDBF_a alphas_a n_alphas_a vecsDisp idx_disp idxBoundles anisDBF] = ...
            solve_DBF_Anisotropic(dir_peaks,np,nRotations,paramsDBF,DBFsFoc_max,idx_Peaks,meas,protocol,sig)

    bs = GetB_Values(protocol)';
    idxB0 = (bs==0);
    idxDW = (bs~=0);
    

    S0r = mean(meas(idxB0));
    Si = meas(idxDW);

    
    [anisDBF vecsDisp idxBoundles]  = ...
        anisotropicDBFFromDirs(dir_peaks,np,paramsDBF(1),paramsDBF(2),paramsDBF(3),protocol ,DBFsFoc_max,idx_Peaks,nRotations);
    
    A_a = S0r*anisDBF;
    alphas_a  = lsqnonneg(A_a,Si);

    n_alphas_a = sum(alphas_a(1:end-1) > 0.05);

    pred_DBF_S_a        = meas;
    pred_DBF_S_a(idxDW) = A_a*alphas_a;
    
    [dummy idx_disp] = max(alphas_a(1:end-1));
    

    loglikDBF_a = RicianLogLik(meas, pred_DBF_S_a, sig);

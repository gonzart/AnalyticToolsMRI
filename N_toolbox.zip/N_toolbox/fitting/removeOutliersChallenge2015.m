function [ss,bval, bvec,G,delta,DELTA, TE,idxNewSet] = removeOutliersChallenge2015(ss,bval, bvec,G,delta,DELTA, TE,idxToRemove)

        idxtot = 1:length(bval);
        idxnew = setdiff(idxtot,idxToRemove);
        
        idxNewSet = 1:length(bval);
        idxNewSet = idxNewSet(idxnew);

        bval = bval( idxnew );
        bvec = bvec(idxnew,:);
        G = G(idxnew);
        delta = delta(idxnew);
        DELTA = DELTA(idxnew);
        TE = TE(idxnew);
        ss=ss(idxnew);
        

end

function [Cost,nmas,nmenos,asignedDirs] = PDDAssigment_and_NError(NGT,FibreDirGT,nB,dirB)


    
    nmenos = 0;
    nmas = 0;
    Cost = 0;
    asignedDirs = dirB;
    
    if nB > NGT
        nmas = 1;
    elseif nB < NGT
        nmenos =  1;
    else
        
        dots = abs(FibreDirGT*dirB'); dots(dots>1) = 1;
        dots = acos(dots)*180/pi;
        [Matching,Cost] = Hungarian(dots);
        Cost = Cost / NGT;
        
        for i=1:NGT
            asignedDirs(i,:) = dirB(find(Matching(i,:)==1),:);
        end
    end



end
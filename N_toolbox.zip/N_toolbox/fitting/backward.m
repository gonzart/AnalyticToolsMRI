%backward backward substitution for 4x4 lower triangular systems
% Written by <YOUR NAME> on <TODAY?S DATE>
function x = backward( A, b )
N = size(A,1);
x = zeros(N,1);
x(N) = b(N)/A(N,N);
for i = N-1:-1:1, % i starts at 2, end at 4, w/ steps of 1
    x(i) = (b(i)-A(i,i+1:N)*x(i+1:N))/A(i,i);
end

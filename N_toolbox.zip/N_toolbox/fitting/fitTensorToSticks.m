function [x, fval, SPredStickBall ] = fitTensorToSticks(nSticks,SSticks,SBall, protocol,meas,sig,x0f)

    %D = 1;
    %stickSC = 0;

    options=optimset('Algorithm', 'active-set', 'Display', 'iter', 'MaxIter',100,...
           'MaxFunEvals',20000,'TolX',1e-6,...
           'TolFun',1e-6,'GradObj','off', 'Hessian', 'off', 'FunValCheck',...
           'on' , 'Display', 'off' ,'DerivativeCheck','on');
    
       
    bs = GetB_Values(protocol)';
    idxB0 = (bs==0);
    idxDW = (bs~=0);

    SStick = zeros(protocol.totalmeas,1);
    SStick(idxDW) = sum(SSticks(idxDW),2);
    SStick(idxB0) = mean(SSticks(idxB0),2);
    
    
    

    fun = @(x)fobj_rician_st_sticks(x,meas,protocol,sig,SStick,SBall);
    
    % Run the opt.
    %x0f = [0.05 0.5 0.0506 1.7e-9 0.7e-9 0.7e-9 0 0 0];
    
    A = [];b=[]; Aeq=[];beq=[]; nonlcon=[];
    lb = [0.0 0.0   0.0506-0.01    -20e-9 -20e-9 -20e-9 -20e-9 -20e-9 -20e-9 ];
    ub = [0.1  1    0.0506+0.01     20e-9  20e-9  20e-9  20e-9  20e-9  20e-9 ];
    
    [x,fval,exitflag,output,lambda,grad,hessian] = fmincon(fun,x0f,A,b,Aeq,beq,lb,ub,nonlcon,options); % ,varargin{:}, fix, x0);

        
    SPredStickBall = SynthMeasSticks(x,protocol,SStick,SBall);

    
end



function sumRes = fobj_rician_st_sticks(xsc, meas, protocol, sig,SStick,SBall)

    E = SynthMeasSticks(xsc,protocol,SStick,SBall);
    sumRes = -RicianLogLik(meas, E, sig);
    if isinf(sumRes)
        sumRes = sumRes;
    end
end

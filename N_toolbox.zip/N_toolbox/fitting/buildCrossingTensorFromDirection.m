function [T1, T2] = buildCrossingTensorFromDirection(d_long1,d_radi1,direc1,d_long2,d_radi2,direc2)





    %%%%%%%%%%%%%%%%%%%%%%%%%%%

    T1 = diag([d_long1 d_radi1 d_radi1]);    
    T2 = diag([d_long2 d_radi2 d_radi2]);

    
    R = fromToRotation([1; 0; 0], direc1);
    T1 = R*T1*R';

       
    R = fromToRotation([1; 0; 0], direc2);
    T2 = R*T2*R';

end
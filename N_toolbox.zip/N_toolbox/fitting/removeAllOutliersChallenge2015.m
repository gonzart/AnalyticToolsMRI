function [meas,bval, bvec,G,delta,DELTA,TE] = removeAllOutliersChallenge2015(meas,bval, bvec,G,delta,DELTA, TE,idxToRemoveB0)


return;


[meas,bval, bvec,G,delta,DELTA, TE] = removeOutliersChallenge2015(meas,bval, bvec,G,delta,DELTA, TE,idxToRemoveB0);
protocol = Challenge2015_2_Protocol(bval, bvec,G,delta,DELTA,TE); % protocol sin B0 outiers


outliersDW = detectOutliersDW(meas, protocol);
idxDWOk = setdiff(1:length(meas),outliersDW);
meas=meas(idxDWOk);bval=bval(idxDWOk); bvec=bvec(idxDWOk,:); G=G(idxDWOk); delta=delta(idxDWOk); DELTA=DELTA(idxDWOk); TE=TE(idxDWOk);


end
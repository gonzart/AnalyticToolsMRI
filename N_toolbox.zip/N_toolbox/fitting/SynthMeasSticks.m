function SStickTensorB0Ball = SynthMeasSticks(xsc,protocol,SStick,SBall)
% xsc = [alpha1 alpha2 alpha3 d1 .. d6]
    d = xsc(4:9);
    T = [d(1) d(4) d(5); d(4) d(2) d(6); d(5) d(6) d(3)];
    
    
    bs = GetB_Values(protocol)';
    idxB0 = (bs==0);
    idxDW = (bs~=0);

    b0 = mean(SStick(idxB0));
    bs = bs(idxDW);
    lecDir = protocol.grad_dirs(idxDW,:);
    
    NLEC = size(bs,1);
    STensor = zeros(NLEC,1);
    for i=1:NLEC
        STensor(i) = exp(-bs(i) * lecDir(i,:) * T * lecDir(i,:)');
    end
    STensor = b0*STensor;
    
    
    SStickTensorB0Ball = SStick;
    SStickTensorB0Ball(idxDW) =  xsc(1)*SBall(idxDW) + ...
                                (1-xsc(1)) * (xsc(2)*SStick(idxDW) + (1-xsc(2))*STensor ) + ... 
                                xsc(3);
end

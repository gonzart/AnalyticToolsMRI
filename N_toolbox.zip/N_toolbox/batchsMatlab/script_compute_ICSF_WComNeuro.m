% Computing an estimation of Intra Cellular Volume Fraction on data
% For the Workshop on Computational Neuroscience 2019, Guanajuato
%
% Author: Dr. Alonso Rami'rez, CIMAT, based on NODDI toolbox

function script_compute_ICSF_WComNeuro()

    clc
    clear
    close all

    addpath(genpath('/Users/alram/CIMAT/presentaciones/workshop_compu_neurosciences_2019/N_toolbox'))

    % Change to working directory
    cd /Users/alram/CIMAT/presentaciones/workshop_compu_neurosciences_2019/DW_MR_Data


    % model to be used, sticks for axons (intracellular), Tortuosity for
    % Zeppeling in extracellular and balls for free water
    model_str = 'WatsonSHStickTortIsoV_B0';
    noddi = MakeModel(model_str);

    % defining the acquisition MR protocol
    protocol = FSL2Protocol('NODDI_protocol.bval', 'NODDI_protocol.bvec');

    % converting files, no need if you already have
    % the file "NODDI_ROI_Slice.mat"
    % CreateROI_WComNeuro('NODDI_DWI.hdr', 'roi_mask.hdr', 'NODDI_ROI_Slice.mat');

    display_input(protocol)

    batch_fitting('NODDI_ROI_Slice.mat', protocol, noddi, 'FittedParams_ROI_Slice.mat');


    SaveParamsAsNIfTI_WComNeuro('FittedParams_ROI_Slice.mat', 'NODDI_ROI_Slice.mat', 'brain_mask.hdr', 'ICSF_Slice')


    display_output();

end

function display_input(protocol)
    warning('off','MATLAB:unknownElementsNowStruc') %removing warnings to avoid installing nifti library
    warning('off','MATLAB:unknownObjectNowStruct')
    data = load('NODDI_ROI_Slice.mat');

    
    handle = implay(imresize(data.sample_B0,3),10);
    handle.Parent.Position = [100 100 700 550];
    fprintf('\n\nThis a reference T2 Magnetic Resonance image, Press Enter to Continue ...\n')
    pause;

    handle = implay(imresize(data.sample_DW,3),10);
    handle.Parent.Position = [100 100 700 550];
    fprintf('\n\nThis a Diffusion Weighted Magnetic Resonance image, Press Enter to Continue ...\n')
    pause;
    
    
    seeSignalQlty(data.roi(2834,:) ,data.roi(2834,:),protocol,[1;0;0],data.roi(2834,1)); title('Example of a 2 Shells (Blue and Red) DW-MR signal from a voxel')
    fprintf('\n\nThis an example of the Diffusion Weighted Magnetic Resonance signal in a voxel, Press Enter to Continue ...\n')
    pause;
end

function display_output()
    data = load('ICSF_Slice.mat');
    figure; imshow(imresize(data.vol_ICSF(:,:,26),3)); title 'An estimation of the intracellular volume fraction'
    colormap('jet')
    fprintf('\n\nThis an estimation of the intracellular volume fraction\n')

    warning('on','MATLAB:unknownElementsNowStruc')
    warning('on','MATLAB:unknownObjectNowStruct') %reactivating warnings removed in display_input() function
end


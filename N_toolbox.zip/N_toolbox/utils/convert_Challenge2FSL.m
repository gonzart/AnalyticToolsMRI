% convert from challenge to FSL


function main_fsl_chall
    clc
    close all



    cd /Users/alram/Dropbox/matlabs/source/PointSets
    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % convert bvec bvals 

    
    vals = load ('bvalue3b0_66.txt')';
    
    vecs = load('R3_3b0_066_orientations.txt');
    vecs = vecs';
    
    save 3b0_066_protocol.bval vals -ASCII
    save 3b0_066_protocol.bvec vecs -ASCII


    
    return
    
    
    cd /Users/alram/FAMAT/investigacion/London2013/NODDI/challenge2014/Gradient_110_Nifti/

    % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % create mask


    targetfile = ['mask.nii']

    %load the target volume
    fprintf('loading the target volume : %s\n', targetfile);
    target = nifti(targetfile);
    xsize = target.dat.dim(1);
    ysize = target.dat.dim(2);
    if length(target.dat.dim) == 2
        zsize = 1;
    else
        zsize = target.dat.dim(3);
    end
    total = xsize*ysize*zsize;
    niftiSpecs.dim = [xsize ysize zsize];
    niftiSpecs.mat = target.mat;
    niftiSpecs.mat_intent = target.mat_intent;
    niftiSpecs.mat0 = target.mat0;
    niftiSpecs.mat0_intent = target.mat0_intent;
    
    mask = target.dat(:,:,:);
    figure; imshow(mask,[])
    
    mask(mask == 1) = 0;
    mask(2,2) = 1;
    mask(12,12) = 1;
    mask(8,11) = 1;
    mask(5,5) = 1;
    mask(10,14) = 1;
    
    figure; imshow(mask,[])
    
    output= 'mask_cros_no_cros.nii';
    
    SaveAsNIfTI(mask, niftiSpecs, output);


    
% 
%     targetfile = 'noddi_challenge_all_kappa.nii'
%     data = nifti(targetfile);
%     data = data.dat(:,:,:,:);
%     figure; imshow(data,[])
%     
%     targetfile = 'mask_crossing.nii'
%     mask = nifti(targetfile);
%     mask = mask.dat(:,:,:,:);
%     figure; imshow(mask,[])
%     
%     v = data(mask == 1)
%     
%     %v = v(v<.15)
%     
%     figure; hist(v,20)
%     
%     mean(v)
%     
    
    
    
%     targetfile = 'nPdds_r.nii'
% 
%     %load the target volume
%     fprintf('loading the target volume : %s\n', targetfile);
%     target = nifti(targetfile);
%     xsize = target.dat.dim(1);
%     ysize = target.dat.dim(2);
%     if length(target.dat.dim) == 2
%         zsize = 1;
%     else
%         zsize = target.dat.dim(3);
%     end
%     total = xsize*ysize*zsize;
%     niftiSpecs.dim = [xsize ysize zsize];
%     niftiSpecs.mat = target.mat;
%     niftiSpecs.mat_intent = target.mat_intent;
%     niftiSpecs.mat0 = target.mat0;
%     niftiSpecs.mat0_intent = target.mat0_intent;
%     
%     mask = target.dat(:,:,:);
%     figure; imshow(mask,[])
%     
%     mask(6,9) = 2;
%     
%     mask(mask~=1) = 0;
%     %mask(mask==2) = 1;
%     
%     
%     figure; imshow(mask,[])
%     
%     output= 'mask_crossing.nii';
%     
%     SaveAsNIfTI(mask, niftiSpecs, output);



%     % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% 
%     path1 = '/Users/alram/FAMAT/investigacion/London2013/NODDI/challenge2014/Gradient_60_Nifti/';
%     path2 = '/Users/alram/FAMAT/investigacion/London2013/NODDI/challenge2014/Gradient_30_Nifti/';
%     path3 = '/Users/alram/FAMAT/investigacion/London2013/NODDI/challenge2014/Gradient_20_Nifti/';
%     targetfile1 = 'Gradient_60.nii';
%     targetfile2 = 'Gradient_30.nii';
%     targetfile3 = 'Gradient_20.nii';
% 
%     % load the target volume
%     fprintf('loading the target volume : %s\n', targetfile1);
% 
%     [data1 xsize1 ysize1 zsize1 ndirs1 niftiSpecs1] = readNifti_andData([path1 targetfile1]);
%     [data2 xsize2 ysize2 zsize2 ndirs2 niftiSpecs2] = readNifti_andData([path2 targetfile2]);
%     [data3 xsize3 ysize3 zsize3 ndirs3 niftiSpecs3] = readNifti_andData([path3 targetfile3]);
% 
%     
%     newData = zeros(xsize1, ysize1, zsize1, ndirs1+ndirs2+ndirs3);
%     
%     newData(:,:,:,1:ndirs1) = data1;
%     newData(:,:,:,ndirs1+1:ndirs1+ndirs2) = data2;
%     newData(:,:,:,ndirs1+ndirs2+1:ndirs1+ndirs2+ndirs3) = data3;
%     
%     niftiSpecs1.dim(4) = ndirs1+ndirs2+ndirs3;
%     
%     pathO = '/Users/alram/FAMAT/investigacion/London2013/NODDI/challenge2014/Gradient_110_Nifti/';
%     fileO = 'Gradient_110.nii';
% 
%     output = [pathO fileO]; 
%     SaveAsNIfTI(newData, niftiSpecs1, output);
%     
%     
%     % convert bvec bvals 
% 
%     
%     vals1 = load ([path1 'bvalue.txt'])';
%     vals2 = load ([path2 'bvalue.txt'])';
%     vals3 = load ([path3 'bvalue.txt'])';
%     
%     vals = [vals1 vals2 vals3];
%     cd(pathO)
%     save Challenge_protocol.bval vals -ASCII
%     
%     
%     
%     vecs1 = load([path1 'bvec.txt']);
%     vecs2 = load([path2 'bvec.txt']);
%     vecs3 = load([path3 'bvec.txt']);
%     vecs = [vecs1' vecs2' vecs3'];
%     
%     save Challenge_protocol.bvec vecs -ASCII
% 
% 




end



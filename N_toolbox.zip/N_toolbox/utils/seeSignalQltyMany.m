function seeSignalQltyMany(meas,S,protocol,recoveredFibreDir,b0,handle)

    %return;
    
    % vizualize  signal quality
    figure(handle);
    VoxelDataViewer(protocol, meas, recoveredFibreDir, b0, handle)
    Plot_Signal(S,protocol,recoveredFibreDir,b0,handle)
    ylim([0 1.1])
end

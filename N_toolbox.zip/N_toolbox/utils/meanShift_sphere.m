function [modes association]= meanShift_sphere(q,p,nItera,sigma)

    
    N = size(q,1);
    
    modes = zeros(1,3);
    votaModes = zeros(1,1);
    contaModes = 0;
    association = zeros(N,1);
    
    for i=1:N % for each direction
        
        dkm1 = p(i,:)';  
        k=0;
        while 1 
            if k > nItera
                break;
            end
            
            
            dotsP = dkm1' * p';
            ws_G = kGauss(dotsP,sigma);
            signs = sign(dotsP);
            scalar = signs.*ws_G.*q';
            scalars = [scalar;scalar;scalar];
            direc = sum(p' .* scalars ,2);
            W = sum(q' .* ws_G ,2);
        
            
            
            dk = direc / W;
            dk = dk / norm(dk);
            
            %r = [dk dkm1]
            if norm(dk-dkm1) < 1e-3
                break
            end
            
            dkm1 = dk;
            
            k = k + 1;
        end
        
        %insert new mode
        found = false;
        for j=1:contaModes
            if norm(modes(j,:)' - dk) < 5e-2 || norm(-modes(j,:)' - dk) < 5e-2
                found = true;
                votaModes(j) = votaModes(j) + 1;
                association(i) = j;
                break
            end
        end
        
        if ~found
            contaModes = contaModes + 1;
            modes(contaModes,:) =  dk';
            votaModes(contaModes) = 1;
            association(i) = contaModes;
        end
        
        
    end
    
    
    

end

function v = kGauss(x,s)
    x = 1-abs(x);  % for dot product
    v = exp(-(x.^2/s));
end


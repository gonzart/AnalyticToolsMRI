function h = seeSignalQlty(meas,S,protocol,recoveredFibreDir,b0)

    %return;
    
    % vizualize  signal quality
    h = figure; VoxelDataViewer(protocol, meas, recoveredFibreDir, b0, h)
    Plot_Signal(S,protocol,recoveredFibreDir,b0,h)
    ylim([0 1.1])
end

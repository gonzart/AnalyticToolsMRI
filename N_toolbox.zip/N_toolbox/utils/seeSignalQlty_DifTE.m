function seeSignalQlty_DifTE(meas,S,protocol,recoveredFibreDir)

    %return;
    
    % vizualize  signal quality
    h = figure; VoxelDataViewer_DifTE(protocol, meas, recoveredFibreDir, h)
    Plot_Signal_DifTE(S,protocol,recoveredFibreDir,h)
    %ylim([0 1.1])
end
function fromGradientToCaminoMonteCarlo


gmr = 2*pi*42.576*1e6; %de MHZ/T ->  rad/(sec T)
    %G in  T/m
    %delta  in   sec
    %DELTA in   sec


ipath = '/Users/alram/Dropbox/matlabs/data/NODDI_example_dataset/';


opath = '/Users/alram/Dropbox/tempPrograms/camino/montecarlo/test/';

%%%%%%%%%%%%%%%%%
bvec1 = load([ipath 'DBF_129orientations.dat']);
G1 =  0.2;
DELTA1 = 0.04;
delta1 = 0.003;
TE1 = 0.067;
bval1 = gmr^2 * G1.^2 .* delta1.^2 .* (DELTA1-delta1/3) ; %
fprintf('\nbvalue = %f mm2/s',bval1/1e6);
%%%%%%%%%%%%%%%%%

bvec2 = load([ipath 'DBF_129orientations.dat']);
G2 =  0.3455;
DELTA2 = 0.04;
delta2 = 0.003;
TE2 = 0.067;
bval2 = gmr^2 * G2.^2 .* delta2.^2 .* (DELTA2-delta2/3) ; %
fprintf('\nbvalue2 = %f mm2/s',bval2/1e6);
%%%%%%%%%%%%%%%%%
bvec0 = zeros(9,7);

n0 = size(bvec0,1);
ndw1 = size(bvec1,1);
ndw2 = size(bvec2,1);


nameFile = [ num2str(n0) 's0_' num2str(ndw1) 'dw_' num2str(ndw2) 'dw_STEJSKALTANNER.scheme'];

matdat = [ bvec0; ...
    bvec1 G1+zeros(ndw1,1) DELTA1+zeros(ndw1,1) delta1+zeros(ndw1,1) TE1+zeros(ndw1,1);...
    bvec2 G2+zeros(ndw2,1) DELTA2+zeros(ndw2,1) delta2+zeros(ndw2,1) TE2+zeros(ndw2,1);...
    ];


fid = fopen([opath nameFile],'wt');
fprintf(fid, 'VERSION: 1\n');
fclose(fid);
% have a matrix M(N,3) ready to go
dlmwrite([opath nameFile], matdat,'delimiter', ' ','precision','%.6f', '-append')


end

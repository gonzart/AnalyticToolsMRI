function vizualizeSignal_noB0(protocol,Si_noB0,newsize,SRecover_noB0,fibredir)

protocol.delta(setdiff([1:81], protocol.b0_Indices));
protocol.delta = protocol.delta(setdiff([1:81], protocol.b0_Indices));
protocol.smalldel = protocol.smalldel(setdiff([1:81], protocol.b0_Indices));
protocol.G = protocol.G(setdiff([1:81], protocol.b0_Indices));
protocol.grad_dirs = protocol.grad_dirs(setdiff([1:81], protocol.b0_Indices),:);
protocol.b0_Indices = [];
protocol.totalmeas = newsize;

h = figure;
VoxelDataViewer(protocol, Si_noB0, fibredir, 1, h);
ylim([0 1]);
hold;
VoxelDataViewer(protocol, SRecover_noB0, fibredir, 1, h, '.');
end
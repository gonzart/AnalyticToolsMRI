function [data, xsize, ysize, zsize, ndirs, ndirs2, niftiSpecs] = readNifti_andData(targetfile)
    target = nifti(targetfile);
    xsize = target.dat.dim(1);
    ysize = target.dat.dim(2);
    if length(target.dat.dim) < 3
        zsize = 1;
    else
        zsize = target.dat.dim(3);
    end
    if length(target.dat.dim) < 4
        ndirs = 1;
    else
        ndirs = target.dat.dim(4);
    end
    if length(target.dat.dim) < 5
        ndirs2 = 1;
    else
        ndirs2 = target.dat.dim(5);
    end
    
    %total = xsize*ysize*zsize;
    niftiSpecs.dim = [xsize ysize zsize ndirs ndirs2];
    niftiSpecs.mat = target.mat;
    niftiSpecs.mat_intent = target.mat_intent;
    niftiSpecs.mat0 = target.mat0;
    niftiSpecs.mat0_intent = target.mat0_intent;
    niftiSpecs.dtype = target.dat.dtype;
    
    
    data  = target.dat(:,:,:,:,:,:);

end
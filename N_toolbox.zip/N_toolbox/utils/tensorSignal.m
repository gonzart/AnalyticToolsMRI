function STensorProt = tensorSignal(D,protocol,b0)

    bs = GetB_Values(protocol)';
    idxB0 = (bs==0);
    idxDW = (bs~=0);

    T = MakeDT_Matrix(D(2), D(3), D(4), D(5), D(6), D(7));
    
    %[a b] = eig(T);
    
    
        
    
    bs = bs(idxDW);
    lecDir = protocol.grad_dirs(idxDW,:);
    
    NLEC = size(bs,1);
    STensor = zeros(NLEC,1);
    for i=1:NLEC
        STensor(i) = exp(-bs(i) * lecDir(i,:) * T * lecDir(i,:)');
    end
    STensor = b0*STensor;
    
    STensorProt(idxB0) = b0;
    STensorProt(idxDW) = STensor;
    STensorProt = STensorProt';

end
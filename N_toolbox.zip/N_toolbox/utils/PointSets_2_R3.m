
sCardBase = '066';

g = load(['/Volumes/alram/FAMAT/fromMacToMac/camino/PointSets/Elec' sCardBase '.txt']); g = g(2:size(g,1)); g = reshape(g,3,size(g,1)/3)';

fname = [  '/Volumes/alram/FAMAT/fromMacToMac/camino/PointSets/R3_' sCardBase '_orientations.txt'];
    
save(fname, 'g','-ASCII', '-TABS');

for i=1:str2num(sCardBase)
    disp(norm(g(i,:)))
end
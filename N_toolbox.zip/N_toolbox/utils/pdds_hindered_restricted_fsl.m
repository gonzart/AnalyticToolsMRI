function pdds_hindered_restricted_fsl(pdds_h,pdds_r,hindSC,restSC,nPdds_h,nPdds_r,targetfile)


    [ren, col, slices nPdds coord] = size(pdds_r);

    %pdds_r = zeros([ren, col, slices 3 3]);

    pdds_1_h = zeros([ren, col, slices 3]);
    pdds_2_h = zeros([ren, col, slices 3]);
    pdds_3_h = zeros([ren, col, slices 3]);

    pdds_1_r = zeros([ren, col, slices 3]);
    pdds_2_r = zeros([ren, col, slices 3]);
    pdds_3_r = zeros([ren, col, slices 3]);

    the_slice = 1;
    
%     pdds_1_h(:,:,the_slice,:) = squeeze(pdds_h(:,:,the_slice,1,:));
%     pdds_2_h(:,:,the_slice,:) = squeeze(pdds_h(:,:,the_slice,2,:));
%     pdds_3_h(:,:,the_slice,:) = squeeze(pdds_h(:,:,the_slice,3,:));
% 
%     pdds_1_r(:,:,the_slice,:) = squeeze(pdds_r(:,:,the_slice,1,:));
%     pdds_2_r(:,:,the_slice,:) = squeeze(pdds_r(:,:,the_slice,2,:));
%     pdds_3_r(:,:,the_slice,:) = squeeze(pdds_r(:,:,the_slice,3,:));
    
    
    for k = 1:3
        pdds_1_h(:,:,the_slice,k) = squeeze(pdds_h(:,:,the_slice,1,k)) .* hindSC;
        pdds_2_h(:,:,the_slice,k) = squeeze(pdds_h(:,:,the_slice,2,k)) .* hindSC;
        pdds_3_h(:,:,the_slice,k) = squeeze(pdds_h(:,:,the_slice,3,k)) .* hindSC;

        pdds_1_r(:,:,the_slice,k) = squeeze(pdds_r(:,:,the_slice,1,k)) .* restSC;
        pdds_2_r(:,:,the_slice,k) = squeeze(pdds_r(:,:,the_slice,2,k)) .* restSC;
        pdds_3_r(:,:,the_slice,k) = squeeze(pdds_r(:,:,the_slice,3,k)) .* restSC;
        
    end

    %load the target volume
    fprintf('loading the target volume : %s\n', targetfile);
    target = nifti(targetfile);
    xsize = target.dat.dim(1);
    ysize = target.dat.dim(2);
    if length(target.dat.dim) == 2
        zsize = 1;
    else
        zsize = target.dat.dim(3);
    end
    %total = xsize*ysize*zsize;
    niftiSpecs.dim = [xsize ysize zsize 3];
    niftiSpecs.mat = target.mat;
    niftiSpecs.mat_intent = target.mat_intent; %% change this
    niftiSpecs.mat0 = target.mat0;
    niftiSpecs.mat0_intent = target.mat0_intent; %% change this
    
    SaveAsNIfTI(pdds_1_h, niftiSpecs, 'pdds_1_h_xyz.nii');
    SaveAsNIfTI(pdds_2_h, niftiSpecs, 'pdds_2_h_xyz.nii');
    SaveAsNIfTI(pdds_3_h, niftiSpecs, 'pdds_3_h_xyz.nii');


    SaveAsNIfTI(pdds_1_r, niftiSpecs, 'pdds_1_r_xyz.nii');
    SaveAsNIfTI(pdds_2_r, niftiSpecs, 'pdds_2_r_xyz.nii');
    SaveAsNIfTI(pdds_3_r, niftiSpecs, 'pdds_3_r_xyz.nii');


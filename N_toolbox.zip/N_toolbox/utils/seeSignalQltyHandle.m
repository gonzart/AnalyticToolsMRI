function seeSignalQltyHandle(meas,S,protocol,recoveredFibreDir,b0,h)

    % vizualize  signal quality
    %h = figure; 
    VoxelDataViewer(protocol, meas, recoveredFibreDir, b0, h)
    Plot_Signal(S,protocol,recoveredFibreDir,b0,h)
    ylim([0 1.1])
    hold off;
end

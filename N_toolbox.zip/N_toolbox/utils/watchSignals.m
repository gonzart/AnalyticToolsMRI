function watchSignals(voxel,protocol)

%cd /Users/alram/FAMAT/investigacion/London2013/NODDI/challenge2014/Gradient_110_Nifti/
%load('NODDI_roi.mat');

%protocol = FSL2Protocol('Challenge_protocol.bval', 'Challenge_protocol.bvec');

bs = GetB_Values(protocol)';

idxDW1000 = (bs==1e9);
idxDW2000 = abs(bs-2e9)<0.9e9;
idxDW3000 = abs(bs-3e9)<1e6;



%voxel = roi(mask(10,14),:)';
%figure; title 'clear voxel without crossings'
%figure; title 'tentative voxel without crossing'
figure; title 'tentative voxel with crossing'


hold on

%scatter3(voxel.*protocol.grad_dirs(:,1), voxel.*protocol.grad_dirs(:,2), voxel.*protocol.grad_dirs(:,3))
%scatter3(-voxel.*protocol.grad_dirs(:,1), -voxel.*protocol.grad_dirs(:,2), -voxel.*protocol.grad_dirs(:,3), 'b')
%return

scatter3(voxel(idxDW1000).*protocol.grad_dirs(idxDW1000,1), voxel(idxDW1000).*protocol.grad_dirs(idxDW1000,2), voxel(idxDW1000).*protocol.grad_dirs(idxDW1000,3),'r')
scatter3(-voxel(idxDW1000).*protocol.grad_dirs(idxDW1000,1), -voxel(idxDW1000).*protocol.grad_dirs(idxDW1000,2), -voxel(idxDW1000).*protocol.grad_dirs(idxDW1000,3),'r')


scatter3(voxel(idxDW2000).*protocol.grad_dirs(idxDW2000,1), voxel(idxDW2000).*protocol.grad_dirs(idxDW2000,2), voxel(idxDW2000).*protocol.grad_dirs(idxDW2000,3),'k')
scatter3(-voxel(idxDW2000).*protocol.grad_dirs(idxDW2000,1), -voxel(idxDW2000).*protocol.grad_dirs(idxDW2000,2), -voxel(idxDW2000).*protocol.grad_dirs(idxDW2000,3),'k')

scatter3(voxel(idxDW3000).*protocol.grad_dirs(idxDW3000,1), voxel(idxDW3000).*protocol.grad_dirs(idxDW3000,2), voxel(idxDW3000).*protocol.grad_dirs(idxDW3000,3),'b')
scatter3(-voxel(idxDW3000).*protocol.grad_dirs(idxDW3000,1), -voxel(idxDW3000).*protocol.grad_dirs(idxDW3000,2), -voxel(idxDW3000).*protocol.grad_dirs(idxDW3000,3),'b')



end